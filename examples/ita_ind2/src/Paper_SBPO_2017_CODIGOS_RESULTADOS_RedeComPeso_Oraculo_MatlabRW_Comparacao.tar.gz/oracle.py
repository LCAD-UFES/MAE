# -*- coding: utf-8 -*-

import numpy
import pandas
import matplotlib.pyplot as plt

WIN_POINT_VALUE = 0.2
IND_POINT_VALUE = 1.0
WDO_POINT_VALUE = 10.0
DOL_POINT_VALUE = 50.0

WIN_QTY = 50#1
IND_QTY = 10#5
WDO_QTY = 25#1
DOL_QTY = 5

CAPITAL = 125000.0

# g_win_capital = 125000.0
# g_ind_capital = 125000.0
# g_wdo_capital = 125000.0
# g_dol_capital = 125000.0
# 
# g_win_n_ops = 0
# g_ind_n_ops = 0
# g_wdo_n_ops = 0
# g_dol_n_ops = 0

def calculate_u_theil(t, y):
    
    num = 0
    den = 0
        
    for i in range(0, len(t)):
        num += (t[i] - y[i]) * (t[i] - y[i])
        
    for i in range(len(t) - 1):
        den += (t[i] - t[i+1]) * (t[i] - t[i+1])
    
    if den > 0:
        return num / den
    else:
        return -1

def calculate_pocid(t, y):
    
    d = 0

    for i in range(1, len(t)):
        if (t[i] - t[i-1])*(y[i] - y[i-1]) > 0:
            d += 1
      
    return 100.0 * d / len(t)

def calculate_arv(t, y):
    
    mean_t = numpy.mean(t)
    num = 0
    den = 0

    for i in range(0, len(t)):
        num += (y[i] - t[i]) * (y[i] - t[i])
        den += (y[i] - mean_t) * (y[i] - mean_t)
        
    if den > 0:
        return (1.0 / len(t)) * (num / den)
    else:
        return -1
 
def calculate_hit_rate(t, y):
    
    hits = 0
    miss = 0
    for i in range(0, len(y)):       
        if y[i] > 0 and t[i] > 0:
            hits += 1
        elif y[i] <= 0 and t[i] <= 0:
            hits += 1
        else:
            miss += 1
        
    return hits, miss

def calculate_mse(t, y):
    
    mse = 0
    for i in range(0, len(t)):
        mse += (y[i] - t[i]) * (y[i] - t[i])
        
    return mse / len(t)

def calculate_metrics(t, y):

    for i in range(4):
        if i == 0:
            print "WIN ",
        elif i == 1:
            print "IND ",
        elif i == 2:
            print "WDO ",
        else:
            print "DOL ",
        testTheil = calculate_u_theil(t[:, i], y[:, i])
        print ('U Theil= %.6lf ' % (testTheil)),
        testArv = calculate_arv(t[:, i], y[:, i])
        print ('ARV= %.6lf' % (testArv)),
        testPocid = calculate_pocid(t[:, i], y[:, i])
        print ('POCID= %.6lf%% ' % (testPocid)),
        hits, misses = calculate_hit_rate(t[:, i], y[:, i])
        print ('Hit Rate= %.6lf%%' % (100.0*hits/(hits+misses))),
        mse = calculate_mse(t[:, i], y[:, i])
        print ('MSE= %.6lf RMSE = %.6f' % (mse, numpy.sqrt(mse)))

def load_data(filename):

    data = pandas.read_csv(filename, sep=';')
    data = data.values
    return data

def from_contract_points_to_money(v, i):
    
    if i == 0: #WIN
        v = 100.0 * (v * WIN_POINT_VALUE * WIN_QTY) / CAPITAL 
    elif i == 1: #IND
        v = 100.0 * (v * IND_POINT_VALUE * IND_QTY) / CAPITAL
    elif i == 2: #WDO
        v = 100.0 * (v * WDO_POINT_VALUE * WDO_QTY) / CAPITAL
    else: #DOL
        v = 100.0 * (v * DOL_POINT_VALUE * DOL_QTY) / CAPITAL

    return v

def get_target_output(data):
    
    #Values are read in contract points
    #WIN, IND, WDO, DOL
    
    t = from_contract_points_to_money(data[:, 0], 0)
    t = numpy.column_stack((t, from_contract_points_to_money(data[:, 2], 1)))
    t = numpy.column_stack((t, from_contract_points_to_money(data[:, 4], 2)))
    t = numpy.column_stack((t, from_contract_points_to_money(data[:, 6], 3)))
    
    y = from_contract_points_to_money(data[:, 1], 0)
    y = numpy.column_stack((y, from_contract_points_to_money(data[:, 3], 1)))
    y = numpy.column_stack((y, from_contract_points_to_money(data[:, 5], 2)))
    y = numpy.column_stack((y, from_contract_points_to_money(data[:, 7], 3)))
    
    return t, y
    
def oracle(data):
    
    win_capital = 0
    ind_capital = 0
    wdo_capital = 0
    dol_capital = 0
    
    win_n_ops = 0
    ind_n_ops = 0
    wdo_n_ops = 0
    dol_n_ops = 0
    
    for i in range(0, len(data)):
        if data[i, 1] > 0: # WIN
            win_capital += data[i, 1] * WIN_QTY * WIN_POINT_VALUE
            win_n_ops += 1
        if data[i, 2] > 0: # IND
            ind_capital += data[i, 2] * IND_QTY * IND_POINT_VALUE
            ind_n_ops += 1
        if data[i, 3] > 0: # WIN
            wdo_capital += data[i, 3] * WDO_QTY * WDO_POINT_VALUE
            wdo_n_ops += 1
        if data[i, 4] > 0: # WIN
            dol_capital += data[i, 3] * DOL_QTY * DOL_POINT_VALUE
            dol_n_ops += 1
            
    return win_capital, win_n_ops, ind_capital, ind_n_ops, wdo_capital, wdo_n_ops, dol_capital, dol_n_ops

def plot_graphs(periods, capital, n_ops, capital_s, n_ops_s, total_intervals, n_days):

#     y_ticks = n_ops[:,0]/n_days
#     y_ticks = numpy.column_stack((y_ticks, n_ops[:,1]/n_days))
#     y_ticks = numpy.column_stack((y_ticks, n_ops[:,2]/n_days))
#     y_ticks = numpy.column_stack((y_ticks, n_ops[:,3]/n_days))

    y_ticks = n_ops.flatten()
    print y_ticks.shape
    y_capital = capital.flatten()
    
   # exit()
    
    plt.plot(periods, n_ops[:,0]/n_days, "b-1")
    plt.plot(periods, n_ops[:,1]/n_days, "g-2")
    plt.plot(periods, n_ops[:,2]/n_days, "r-3")
    plt.plot(periods, n_ops[:,3]/n_days, "k-4")
#     plt.plot(periods, n_ops_s[:,0]/n_days, c="royalblue", marker="8")
#     plt.plot(periods, n_ops_s[:,1]/n_days, c="olive", marker="s")
#     plt.plot(periods, n_ops_s[:,2]/n_days, c="brown", marker="p")
#     plt.plot(periods, n_ops_s[:,3]/n_days, c="dimgrey", marker="*")
    plt.xticks(periods)
    plt.tick_params(axis="both", labelsize=14)
    #plt.yticks(y_ticks/n_days)
#     plt.legend(["WIN Long", "IND Long", "WDO Long", "DOL Long", "WIN Short", "IND Short", "WDO Short", "DOL Short"], prop={"size":10})
    plt.legend(["WIN", "IND", "WDO", "DOL"], prop={"size":12}, loc="upper center", ncol=4)
    plt.xlabel("Escala de Tempo t (segundos)", fontsize=18)
    plt.ylabel(u"Número de Operações", fontsize=18)
    #plt.title(u"Número Operações X Escala de Tempo", fontsize=18)
    
    plt.figure()
    plt.plot(periods, 100.0*n_ops[:,0]/total_intervals[:,0], "b-1")
    plt.plot(periods, 100.0*n_ops[:,1]/total_intervals[:,0], "g-2")
    plt.plot(periods, 100.0*n_ops[:,2]/total_intervals[:,0], "r-3")
    plt.plot(periods, 100.0*n_ops[:,3]/total_intervals[:,0], "k-4")
#     plt.plot(periods, n_ops_s[:,0]/total_intervals[:,0], c="royalblue", marker="8")
#     plt.plot(periods, n_ops_s[:,1]/total_intervals[:,0], c="olive", marker="s")
#     plt.plot(periods, n_ops_s[:,2]/total_intervals[:,0], c="brown", marker="p")
#     plt.plot(periods, n_ops_s[:,3]/total_intervals[:,0], c="dimgrey", marker="*")
    plt.xticks(periods)
    plt.tick_params(axis="both", labelsize=14)
    #plt.yticks(y_ticks/total_intervals[:,0])
#     plt.legend(["WIN Long", "IND Long", "WDO Long", "DOL Long", "WIN Short", "IND Short", "WDO Short", "DOL Short"], prop={"size":10})
    plt.legend(["WIN", "IND", "WDO", "DOL"], prop={"size":12}, loc="upper center", ncol=4)
    plt.xlabel("Escala de Tempo t (segundos)", fontsize=18)
    plt.ylabel(u"Percentual de Operações (%)", fontsize=18)
    #plt.title(u"Percentual Operações X Escala de Tempo", fontsize=18)
    
    plt.figure()
    plt.plot(periods, 100.0*(capital[:, 0]/125000.0)/n_days, "b-1")
    plt.plot(periods, 100.0*(capital[:, 1]/125000.0)/n_days, "g-2")
    plt.plot(periods, 100.0*(capital[:, 2]/125000.0)/n_days, "r-3")
    plt.plot(periods, 100.0*(capital[:, 3]/125000.0)/n_days, "k-4")
#     plt.plot(periods, capital_s[:, 0]/n_days, c="royalblue", marker="8")
#     plt.plot(periods, capital_s[:, 1]/n_days, c="olive", marker="s")
#     plt.plot(periods, capital_s[:, 2]/n_days, c="brown", marker="p")
#     plt.plot(periods, capital_s[:, 3]/n_days, c="dimgrey", marker="*")
    plt.xticks(periods)
    plt.tick_params(axis="both", labelsize=14)
    #plt.yticks(y_capital/n_days)
#     plt.legend(["WIN Long", "IND Long", "WDO Long", "DOL Long", "WIN Short", "IND Short", "WDO Short", "DOL Short"], prop={"size":10})
    plt.legend(["WIN", "IND", "WDO", "DOL"], prop={"size":12}, loc="upper center", ncol=4)
    plt.xlabel("Escala de Tempo t (segundos)", fontsize=18)
    plt.ylabel(u"Retorno (%)", fontsize=18)
    #plt.title(u"Lucro Percentual X Escala de Tempo", fontsize=18)
     
    plt.figure()
    plt.plot(periods, 100.0*((capital[:, 0]/125000.0)/n_ops[:,0]), "b-1")
    plt.plot(periods, 100.0*((capital[:, 1]/125000.0)/n_ops[:,1]), "g-2")
    plt.plot(periods, 100.0*((capital[:, 2]/125000.0)/n_ops[:,2]), "r-3")
    plt.plot(periods, 100.0*((capital[:, 3]/125000.0)/n_ops[:,3]), "k-4")
#     plt.plot(periods, capital_s[:,0]/n_ops[:,0], c="royalblue", marker="8")
#     plt.plot(periods, capital_s[:,1]/n_ops[:,1], c="olive", marker="s")
#     plt.plot(periods, capital_s[:,2]/n_ops[:,2], c="brown", marker="p")
#     plt.plot(periods, capital_s[:,3]/n_ops[:,3], c="dimgrey", marker="*")
    plt.xticks(periods)
    plt.tick_params(axis="both", labelsize=14)
#     plt.legend(["WIN Long", "IND Long", "WDO Long", "DOL Long", "WIN Short", "IND Short", "WDO Short", "DOL Short"], prop={"size":10})
    plt.legend(["WIN", "IND", "WDO", "DOL"], prop={"size":12}, loc="upper center", ncol=4)
    plt.xlabel("Escala de Tempo t (segundos)", fontsize=18)
    plt.ylabel(u"Retorno por Operação (%)", fontsize=18)
    #plt.title(u"Lucro Percentual Por Operação X Escala de Tempo", fontsize=18)
    
    plt.show()
    
def main():
    #TODO: NO papar ta os graficos de 30 dias
    n_days = 30
    
    data_32 = load_data("DataOracle/data_30_32s.csv")
    data_64 = load_data("DataOracle/data_30_64s.csv")
    data_128 = load_data("DataOracle/data_30_128s.csv")
    data_256 = load_data("DataOracle/data_30_256s.csv")
    
    data_32_s = load_data("DataOracle/data_short_30_32s.csv")
    data_64_s = load_data("DataOracle/data_short_30_64s.csv")
    data_128_s = load_data("DataOracle/data_short_30_128s.csv")
    data_256_s = load_data("DataOracle/data_short_30_256s.csv")
    
    # PLOTAR GRAFICO DA EVOLUCAO DO DINHEIRO
    # FAZER FUNCAO PRA PODER PASSAR OS ARQUIVOS DOS 4 PERIDOS AO MESMO TEMPO E PLOTAR OS GRAFICOS
    periods = [32, 64, 128, 256]

    total_intervals = numpy.zeros((4, 1))
    total_intervals[0] = len(data_32)
    total_intervals[1] = len(data_64)
    total_intervals[2] = len(data_128)
    total_intervals[3] = len(data_256)
    
    capital = numpy.zeros((4, 4)) 
    n_ops = numpy.zeros((4, 4))

    capital_s = numpy.zeros((4, 4)) 
    n_ops_s = numpy.zeros((4, 4))
    
    capital[0, 0], n_ops[0, 0], capital[0, 1], n_ops[0, 1], capital[0, 2], n_ops[0, 2], capital[0, 3], n_ops[0, 3] = oracle(data_32)
    capital[1, 0], n_ops[1, 0], capital[1, 1], n_ops[1, 1], capital[1, 2], n_ops[1, 2], capital[1, 3], n_ops[1, 3] = oracle(data_64)
    capital[2, 0], n_ops[2, 0], capital[2, 1], n_ops[2, 1], capital[2, 2], n_ops[2, 2], capital[2, 3], n_ops[2, 3] = oracle(data_128)
    capital[3, 0], n_ops[3, 0], capital[3, 1], n_ops[3, 1], capital[3, 2], n_ops[3, 2], capital[3, 3], n_ops[3, 3] = oracle(data_256)

    capital_s[0, 0], n_ops_s[0, 0], capital_s[0, 1], n_ops_s[0, 1], capital_s[0, 2], n_ops_s[0, 2], capital_s[0, 3], n_ops_s[0, 3] = oracle(data_32_s)
    capital_s[1, 0], n_ops_s[1, 0], capital_s[1, 1], n_ops_s[1, 1], capital_s[1, 2], n_ops_s[1, 2], capital_s[1, 3], n_ops_s[1, 3] = oracle(data_64_s)
    capital_s[2, 0], n_ops_s[2, 0], capital_s[2, 1], n_ops_s[2, 1], capital_s[2, 2], n_ops_s[2, 2], capital_s[2, 3], n_ops_s[2, 3] = oracle(data_128_s)
    capital_s[3, 0], n_ops_s[3, 0], capital_s[3, 1], n_ops_s[3, 1], capital_s[3, 2], n_ops_s[3, 2], capital_s[3, 3], n_ops_s[3, 3] = oracle(data_256_s)


    plot_graphs(periods, capital, n_ops, capital_s, n_ops_s, total_intervals, n_days)


if __name__ == "__main__":
    main()