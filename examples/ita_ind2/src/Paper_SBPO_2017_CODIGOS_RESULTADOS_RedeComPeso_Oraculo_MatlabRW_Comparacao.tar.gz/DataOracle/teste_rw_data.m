%diary 'out_teste_random_data.txt'



    
%diary off
[WIN, IND, WDO, DOL] = importfile('data_30_32s.csv', 1, inf);

h = runstest(WIN)
h = runstest(IND)
h = runstest(WDO)
h = runstest(DOL)