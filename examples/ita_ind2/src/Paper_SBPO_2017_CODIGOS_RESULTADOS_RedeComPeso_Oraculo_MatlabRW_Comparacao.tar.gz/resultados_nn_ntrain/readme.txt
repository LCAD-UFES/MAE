Nessa pasta estao os resultados com o treino em n epocas com n igual ao numero de elemetos na hora do treino diario.
