import numpy
import matplotlib.pyplot as plt
import pandas
#import math
from keras.callbacks import EarlyStopping
from keras.models import Sequential
from keras.layers.core import Dense
#from keras.layers.core import Activation, Dense
#from keras.layers import LSTM
#from sklearn.preprocessing import MinMaxScaler
#from sklearn.metrics import mean_squared_error

import datetime as dt

from subprocess import Popen, PIPE
from optparse import OptionParser
from time import sleep

# defines
TRAIN_PHASE = 1
TEST_PHASE = 2

# trading state_machine states
INITIALIZE_STATE = 1
BEGIN_PREDICTION_STATE = 2
TRY_TO_ENTER_STATE = 3
TRY_TO_EXIT_STATE = 4
PLOT_STATE = 5
END_STATE = 6

PLOT_GRAPH = 0

COST_QTY_WIN_WDO = 0.61 
COST_QTY_IND_DOL = 4.43 
WIN_POINT_VALUE = 0.2
IND_POINT_VALUE = 1.0
WDO_POINT_VALUE = 10.0
DOL_POINT_VALUE = 50.0

WIN_QTY = 50#1
IND_QTY = 10#5
WDO_QTY = 25#1
DOL_QTY = 5

COST_WIN_R = (COST_QTY_WIN_WDO * WIN_QTY)
COST_IND_R = (COST_QTY_IND_DOL * IND_QTY)
COST_WDO_R = (COST_QTY_WIN_WDO * WDO_QTY)
COST_DOL_R = (COST_QTY_IND_DOL * DOL_QTY)

CERTAINTY = 55.0

MAX_DATA_SAMPLES = 43200
SS = 0
SD = 1
SN = 2
DS = 3
DD = 4
DN = 5
NS = 6
ND = 7
NN = 8

RETURN = 9
P_RETURN = 10
INVEST = 11
HITS = 12

ACC = 9
GI = 10
Gi = 11

SUBIU = 0
DESCE = 1
NEUTR = 2

MAX_DAYS = 200

# globals g_*
g_net_phase = TRAIN_PHASE 
g_current_state= INITIALIZE_STATE
g_current_result = numpy.zeros((4, 1))
g_last_prediction = numpy.zeros((4, 1))
g_prediction = numpy.zeros((4, 1))
g_confidence = numpy.zeros((4, 2))
g_n_ops = numpy.zeros((4, 1))
g_fn = numpy.zeros((4, 1))
g_fp = numpy.zeros((4, 1))
g_tp = numpy.zeros((4, 1))
g_tn = numpy.zeros((4, 1))
g_n_hits = numpy.zeros((4, 1))
g_n_miss = numpy.zeros((4, 1))
g_buy_sell_count = numpy.zeros((4, 1))
g_capital = numpy.zeros((5, 1)) # pos 5 in general capital
g_results = numpy.zeros((MAX_DATA_SAMPLES, 4, 13))
g_best_stock_pred_i = 0
g_reference_prc_enter = 0
g_reference_prc_exit = 0
g_last_sample_enter = 0
g_last_sample_exit = 0
g_sample_statistics = 0
g_current_sample = 0
g_max_sample = 0
g_min_sample = 0
g_last_sample = 0
g_running_sum_size = 10 #PARAM
g_mean_correct_positive_pred = numpy.zeros((4, 1))
g_mean_reverse_positive_pred = numpy.zeros((4, 1))
g_mean_correct_negative_pred = numpy.zeros((4, 1))
g_mean_reverse_negative_pred = numpy.zeros((4, 1))
g_stat_day = numpy.zeros((MAX_DAYS, 4, 13))
g_stat_exp = []
    
g_dt_format = " %Y-%m-%d %H:%M:%S.%f BRT"
g_train_time = dt.datetime.strptime("12:00:00.0", "%H:%M:%S.%f")
g_test_time = dt.datetime.strptime("13:30:00.0", "%H:%M:%S.%f")
g_test_end_time = dt.datetime.strptime("16:45:00.0", "%H:%M:%S.%f")

class statistics_exp:
    def __init__(self):
        self.day = 0
        self.avg_capital = 0
        self.geral_capital = 0 
        self.n_ops = 0
        self.total_hits = 0
        self.capital_win = 0
        self.n_ops_win = 0
        self.capital_ind = 0
        self.n_ops_ind = 0
        self.capital_wdo = 0
        self.n_ops_wdo = 0
        self.capital_dol = 0
        self.n_ops_dol = 0    
        
class ddata:
    def __init__(self):
        self.dataset = [] #tupla (a, b, c)
        
        self.sample_id = 0
        self.time_id = 1
        
        self.win_id = 2
        self.ind_id = 5
        self.wdo_id = 8
        self.dol_id = 11
        
        self.ask_id = 0
        self.bid_id = 1
        self.mid_id = 2
        
        #self.symbol_name = "NONE"

    def skip_pre_open(self):
        dataset = self.dataset
        for i in range(0, len(dataset)):
            if dataset[i, self.win_id:-1].all() != 0:
                break
        self.dataset = dataset[i:,]
        
def parse_cmdline(parser):
    parser.set_defaults(data_fname="../data.txt")
    parser.set_defaults(period=64)
    parser.set_defaults(n_in=10)
    parser.set_defaults(n_out=1)

    parser.add_option("-D", "--data_fname", dest="data_fname", help="Data file name")
    parser.add_option("-t", "--days_train", dest="days_train", help="Days to train > 0")
    parser.add_option("-p", "--days_test", dest="days_test", help="Days to test > 0")
    parser.add_option("-s", "--seconds", dest="period", help="Period in seconds > 0")
    parser.add_option("-I", "--n_input", dest="n_in", help="Default 10.")
    parser.add_option("-O", "--n_output", dest="n_out", help="Default 1.")

    (options, args) = parser.parse_args()
    
    if options.period <= 0:
        parser.error("Error: seconds <= 0")

    if options.n_in <= 0 or options.n_out <= 0:
        parser.error("Error: n_in <= 0 or n_out <= 0")
        
    return (options, args)

def static_vars(**kwargs):
    def decorate(func):
        for k in kwargs:
            setattr(func, k, kwargs[k])
        return func
    return decorate

def read_day_data_fname(day_i, options):    
    
    with open(options.data_fname) as fp:
        for i, line in enumerate(fp):
            if i == day_i:
                print line
                break
        
    return line

def load_day_data(filename, options):

    data = ddata()
    
    filename = filename.rstrip("\n")

    sample_time = pandas.read_csv(filename, sep=';', usecols=[0,1])
    sample_time = sample_time.values
    
    win = pandas.read_csv(filename, sep=';', usecols=[2, 3])
    win = win.values
    win = numpy.column_stack((win, (win[:, 0] + win[:, 1]) / 2.0))
    
    ind = pandas.read_csv(filename, sep=';', usecols=[4, 5])
    ind = ind.values
    ind = numpy.column_stack((ind, (ind[:, 0] + ind[:, 1]) / 2.0))
    
    wdo = pandas.read_csv(filename, sep=';', usecols=[6, 7])
    wdo = wdo.values
    wdo = numpy.column_stack((wdo, (wdo[:, 0] + wdo[:, 1]) / 2.0))
    
    dol = pandas.read_csv(filename, sep=';', usecols=[8, 9])
    dol = dol.values
    dol = numpy.column_stack((dol, (dol[:, 0] + dol[:, 1]) / 2.0))
    
    dataset = sample_time
    dataset = numpy.column_stack((dataset, win))
    dataset = numpy.column_stack((dataset, ind))
    dataset = numpy.column_stack((dataset, wdo))
    dataset = numpy.column_stack((dataset, dol))
    
    data.dataset = dataset
    
    #print data.dataset[0, :]
    #data.skip_pre_open()
    #print data.dataset[0, :]

    #update globals
    global g_current_sample, g_max_sample, g_min_sample
    g_current_sample = 0
    g_min_sample = 0
    g_max_sample = len(data.dataset)
    #print g_current_sample, g_min_sample, g_max_sample

    return data

def load_day(day_i, options):
    
    day_fname = read_day_data_fname(day_i, options)
    day_data = load_day_data(day_fname, options)
    return day_data

def capital_plot_curvature():
    return 0

@static_vars(pipe=None, y_values=None, x_values=None, i=0, first_time=1, enter_pos=0, exit_pos=0, exited_pos=0, first_sample=0, cost_pts=0)
def prc_plot_curvature(day_data, options, reset, prc, enter, exitv, exited):

    if prc_plot_curvature.y_values is None:
        prc_plot_curvature.y_values = numpy.zeros((options.period, 1))

    if prc_plot_curvature.x_values is None:
        prc_plot_curvature.x_values = numpy.zeros((options.period, 1))
             
    div_value = 1.0  
    if g_best_stock_pred_i == 0:
        symbol = "WIN"
        prc_plot_curvature.cost_pts = COST_QTY_WIN_WDO / WIN_POINT_VALUE
    elif g_best_stock_pred_i == 1:
        symbol = "IND"
        prc_plot_curvature.cost_pts = COST_QTY_IND_DOL / IND_POINT_VALUE
    elif g_best_stock_pred_i == 2:
        symbol = "WDO"
        div_value = 12.5
        prc_plot_curvature.cost_pts = COST_QTY_WIN_WDO / WDO_POINT_VALUE
    elif g_best_stock_pred_i == 3:
        symbol = "DOL"
        div_value = 12.5
        prc_plot_curvature.cost_pts = COST_QTY_IND_DOL / DOL_POINT_VALUE

    if prc_plot_curvature.first_time == 1:
        prc_plot_curvature.first_time = 0
        prc_plot_curvature.pipe = Popen("gnuplot -persist", shell=True, stdin=PIPE) #("gnuplot -persist", "w") to keep last plot after program closes
        #fprintf(gnuplot_pipe, "set autoscale\n")
    if reset == 1:
        prc_plot_curvature.i = 0
        prc_plot_curvature.pipe.stdin.write("set xrange [%d:%d]\n" % (g_current_sample, g_last_sample_exit + 1))
        prc_plot_curvature.pipe.stdin.write("set yrange [-100.0/%lf:100.0/%lf]\n" % (div_value, div_value))
        prc_plot_curvature.first_sample = g_current_sample

    # save values
    prc_plot_curvature.y_values[prc_plot_curvature.i, 0] = prc;
    prc_plot_curvature.x_values[prc_plot_curvature.i, 0] = g_current_sample;
    if enter == 1:# as linhas continuam desenhadas pq escreve direto no pipe
        prc_plot_curvature.enter_pos = prc_plot_curvature.x_values[prc_plot_curvature.i, 0]
        #To draw a vertical line from the bottom to the top of the graph at x=3, use:
        #set arrow from 3, graph 0 to 3, graph 1 nohead
        prc_plot_curvature.pipe.stdin.write("unset arrow\nset arrow from %d, graph 0 to %d, graph 1 nohead\n" % (prc_plot_curvature.enter_pos, prc_plot_curvature.enter_pos))
        prc_plot_curvature.pipe.stdin.write("set arrow from %d,%lf to %d,%lf nohead lc rgb 'green'\n" % (prc_plot_curvature.first_sample, prc + 2 * prc_plot_curvature.cost_pts,
                                                                                                         g_last_sample_exit + 1, prc + 2 * prc_plot_curvature.cost_pts))
        prc_plot_curvature.pipe.stdin.write("set arrow from %d,%lf to %d,%lf nohead lc rgb 'purple'\n" % (prc_plot_curvature.first_sample, prc - 2 * prc_plot_curvature.cost_pts,
                                                                                                         g_last_sample_exit + 1, prc - 2 * prc_plot_curvature.cost_pts))
    elif exitv == 1:
        prc_plot_curvature.exit_pos = prc_plot_curvature.x_values[prc_plot_curvature.i, 0]
        prc_plot_curvature.pipe.stdin.write("set arrow from %d, graph 0 to %d, graph 1 nohead lc rgb 'blue'\n" % (prc_plot_curvature.exit_pos, prc_plot_curvature.exit_pos))
        
    elif exited == 1:
        prc_plot_curvature.exited_pos = prc_plot_curvature.x_values[prc_plot_curvature.i, 0]
        prc_plot_curvature.pipe.stdin.write("set arrow from %d, graph 0 to %d, graph 1 nohead\n" % (prc_plot_curvature.exited_pos, prc_plot_curvature.exited_pos))

    prc_plot_curvature.i += 1

    gnuplot_data_file = open("gnuplot_data.txt", "w")
    for k in range(prc_plot_curvature.i):
        gnuplot_data_file.write("%d %lf\n" % (prc_plot_curvature.x_values[k, 0], prc_plot_curvature.y_values[k, 0]))
    gnuplot_data_file.close()

    prc_plot_curvature.pipe.stdin.write("plot "
            "'./gnuplot_data.txt' using 1:2 with lines title 'DELTA PRC %s'\n" % (symbol))

    #fflush(gnuplot_pipe);

    #// sleep 100ms to update graph
    sleep(0.1)

def sample_previous_period(day_data, options, sample):
    
    initial_time = dt.datetime.strptime(day_data.dataset[sample, day_data.time_id], g_dt_format)

    while sample > g_min_sample:
        current_time = dt.datetime.strptime(day_data.dataset[sample, day_data.time_id], g_dt_format)
        if (initial_time - current_time).total_seconds() >= options.period:
            return sample
        sample -= 1
        
    return -1

def sample_next_period(day_data, options, sample):

    initial_time = dt.datetime.strptime(day_data.dataset[sample, day_data.time_id], g_dt_format)

    while sample < g_max_sample:
        current_time = dt.datetime.strptime(day_data.dataset[sample, day_data.time_id], g_dt_format)
        if (current_time - initial_time).total_seconds() >= options.period:
            return sample
        sample += 1
        
    return -1

def calculate_period_return(day_data, options, idx):
    
    sample = sample_previous_period(day_data, options, g_current_sample)

    data_idx = 0
    cost_pts = 0
    if idx == 0:
        cost_pts = COST_QTY_WIN_WDO / WIN_POINT_VALUE
        data_idx = day_data.win_id + day_data.mid_id
    elif idx == 1:
        cost_pts = COST_QTY_IND_DOL / IND_POINT_VALUE
        data_idx = day_data.ind_id + day_data.mid_id
    elif idx == 2:
        cost_pts = COST_QTY_WIN_WDO / WDO_POINT_VALUE
        data_idx = day_data.wdo_id + day_data.mid_id
    else:
        cost_pts = COST_QTY_IND_DOL / DOL_POINT_VALUE
        data_idx = day_data.dol_id + day_data.mid_id
    
    entered = 0
    exitv = 0
    exited = 0
    enter_prc = 0
    exit_prc = 0
#//    prc_output_plot_curvature(stock, sample, g_current_sample, sample, 1, 0, entered, exit, exited);

    for i in range(sample + 1, g_current_sample):
        curr_prc = day_data.dataset[i, data_idx]
        prev_prc = day_data.dataset[i - 1, data_idx]

        diff_prc = curr_prc - prev_prc
        ret_prc = curr_prc - enter_prc

        # stop loss
        if ( entered == 1 and exitv == 0 and ret_prc <= -2 * cost_pts ):
            exit_prc = curr_prc
            exited = 1
            exitv = 1
            
        # stop gain part 2
        if ( exited == 0 and entered == 1 and exitv == 1 and diff_prc <= 0 ):
            exit_prc = curr_prc
            exited = 1
            
        # stop gain part 1
        if ( entered == 1 and exitv == 0 and ret_prc > 2 * cost_pts ):
            exitv = 1
            
        # enter
        if ( entered == 0 and diff_prc > 0 ):
            enter_prc = curr_prc
            entered = 1

        #//prc_output_plot_curvature(stock, sample, g_current_sample, i, 0, delta_prc, entered, exit, exited);

    if exited == 0:
        curr_prc = day_data.dataset[g_current_sample, data_idx]
        exited = 1
        exit_prc = curr_prc

    #//prc_output_plot_curvature(stock, sample, g_current_sample, g_current_sample, 0, delta_prc, entered, exit, exited);

    if entered == 1:
        val_ret = exit_prc - enter_prc - 2 * cost_pts
    else:
        val_ret = 0

    return val_ret

def choose_best_prediction():
    
    global g_best_stock_pred_i
    
    best_i = 0
    pred = g_prediction[best_i, 0]
    ret = 0

    for i in range(4):
        if g_prediction[i, 0] > pred:
            best_i = i
            pred = g_prediction[i, 0]

    if ( pred > 0 and g_confidence[best_i, 0] >= CERTAINTY and g_confidence[best_i, 1] >= CERTAINTY ):        
        g_best_stock_pred_i = best_i
        ret = 1
    
    return ret

def calculate_limits_sample_enter_exit(day_data, options):
    
    global g_last_sample_enter, g_last_sample_exit
    
    ret = 1
    sample_enter = g_current_sample
    sample_exit = g_current_sample

    sample_enter = sample_next_period(day_data, options, sample_enter)
    sample_exit = sample_next_period(day_data, options, sample_exit)

    g_last_sample_enter = sample_enter
    g_last_sample_exit = sample_exit

    last_enter_time = dt.datetime.strptime(day_data.dataset[g_last_sample_enter, day_data.time_id], g_dt_format)
    last_exit_time = dt.datetime.strptime(day_data.dataset[g_last_sample_exit, day_data.time_id], g_dt_format)

    if ( (last_enter_time.hour > g_test_end_time.hour or last_exit_time.hour > g_test_end_time.hour) or
         (last_enter_time.hour == g_test_end_time.hour and last_enter_time.minute >= g_test_end_time.minute) or
         (last_exit_time.hour == g_test_end_time.hour and last_exit_time.minute >= g_test_end_time.minute)):
        ret = 0

    return ret

def get_symbol_values(day_data, options, symbol):
    
    current_prc = 0
    previous_prc = 0
    qty = 0
    pt_value = 0
    cost = 0
    
    if symbol == 0:
        current_prc = day_data.dataset[g_current_sample, day_data.win_id + day_data.mid_id]
        previous_prc = day_data.dataset[g_current_sample - 1, day_data.win_id + day_data.mid_id]
        qty = WIN_QTY
        pt_value= WIN_POINT_VALUE
        cost = COST_WIN_R
    elif symbol == 1:
        current_prc = day_data.dataset[g_current_sample, day_data.ind_id + day_data.mid_id]
        previous_prc = day_data.dataset[g_current_sample - 1, day_data.ind_id + day_data.mid_id]
        qty = IND_QTY
        pt_value= IND_POINT_VALUE
        cost = COST_IND_R
    elif symbol == 2:
        current_prc = day_data.dataset[g_current_sample, day_data.wdo_id + day_data.mid_id]
        previous_prc = day_data.dataset[g_current_sample - 1, day_data.wdo_id + day_data.mid_id]
        qty = WDO_QTY
        pt_value= WDO_POINT_VALUE
        cost = COST_WDO_R
    elif symbol == 3:
        current_prc = day_data.dataset[g_current_sample, day_data.dol_id + day_data.mid_id]
        previous_prc = day_data.dataset[g_current_sample - 1, day_data.dol_id + day_data.mid_id]
        qty = DOL_QTY
        pt_value= DOL_POINT_VALUE
        cost = COST_DOL_R
        
    return current_prc, previous_prc, qty, pt_value, cost  
        
def try_to_enter_operation(day_data, options):
    
    global g_buy_sell_count
    
    if g_current_sample >= g_last_sample_enter:
        return -1 # END OF TIME 

    current_prc, previous_prc, _, _, _ = get_symbol_values(day_data, options, g_best_stock_pred_i)
    diff_prc = current_prc - previous_prc

    if diff_prc > 0:
        g_buy_sell_count[g_best_stock_pred_i, 0] += 1
        return 1

    return 0

def compute_capital_evolution_st(ret_prc, ret_capital, cost):
    
    global g_capital, g_n_hits, g_results
    
    previous_capital = g_capital[g_best_stock_pred_i, 0]
    g_capital[g_best_stock_pred_i, 0] += ret_capital - 2 * cost
    g_capital[4, 0] += ret_capital - 2 * cost

    if g_capital[g_best_stock_pred_i, 0] > previous_capital:
        g_n_hits[g_best_stock_pred_i, 0] += 1
        g_results[g_sample_statistics - 1, g_best_stock_pred_i, HITS] += 1
    else:
        g_n_miss[g_best_stock_pred_i, 0] += 1

    return 0

@static_vars(exit_enable=0)
def try_to_exit_operation(day_data, options):
    
    global g_tp, g_tn, g_fp, g_fn

    current_prc, previous_prc, qty, point_value, cost = get_symbol_values(day_data, options, g_best_stock_pred_i)

    pt_cost = 0
    if g_best_stock_pred_i == 0:
        pt_cost = COST_QTY_WIN_WDO/WIN_POINT_VALUE
    elif g_best_stock_pred_i == 1:
        pt_cost = COST_QTY_IND_DOL/IND_POINT_VALUE
    elif g_best_stock_pred_i == 2:
        pt_cost = COST_QTY_WIN_WDO/WDO_POINT_VALUE
    elif g_best_stock_pred_i == 3:
        pt_cost = COST_QTY_IND_DOL/DOL_POINT_VALUE

    #TODO: Ter certeza que o custo funciona
    ret_prc = current_prc - g_reference_prc_exit# - mult * pt_cost;
    ret_capital = (current_prc - g_reference_prc_exit) * qty * point_value

    if try_to_exit_operation.exit_enable == 1:
        diff_prc = current_prc - previous_prc
        if diff_prc <= 0: # Comecou a cair
            if (ret_prc > 2 * pt_cost and g_current_result[g_best_stock_pred_i, 0] > 0):
                g_tp[g_best_stock_pred_i, 0] += 1
            elif (ret_prc <= 2 * pt_cost and g_current_result[g_best_stock_pred_i, 0] <= 0):
                g_fp[g_best_stock_pred_i, 0] += 1
            else:
                print("g_best=%d ret_prc=%lf current_res=%lf" % (g_best_stock_pred_i, ret_prc, g_current_result[g_best_stock_pred_i, 0]))

            compute_capital_evolution_st(ret_prc, ret_capital, cost)
            try_to_exit_operation.exit_enable = 0
            return 1

    # stop time
    if g_current_sample >= g_last_sample_exit:
        if (ret_prc > 2 * pt_cost and g_current_result[g_best_stock_pred_i, 0] > 0):
            g_tp[g_best_stock_pred_i, 0] += 1
        elif (ret_prc <= 2 * pt_cost and g_current_result[g_best_stock_pred_i, 0] <= 0):
            g_fp[g_best_stock_pred_i, 0] += 1
        else:
            print("g_best=%d ret_prc=%lf current_res=%lf" % (g_best_stock_pred_i, ret_prc, g_current_result[g_best_stock_pred_i]))

        compute_capital_evolution_st(ret_prc, ret_capital, cost)
        return 1

    #TODO: CONSTS
    #const_mult_loss = 1.0
    #const_mult_gain = 0.5
    # stop loss
    if (ret_prc <= -2 * pt_cost): #/*&& ret_prc <= -const_mult_loss * g_last_predction[g_best_stock_pred_i]*/) //LONG
        g_fp[g_best_stock_pred_i, 0] += 1
        #print("STOP LOSS\n")
        compute_capital_evolution_st(ret_prc, ret_capital, cost)
        return 1

    # stop grain
    if (try_to_exit_operation.exit_enable == 0 and ret_prc > 2 * pt_cost): #/*&& ret_prc >= const_mult_gain * g_last_predction[g_best_stock_pred_i]*/) //LONG
        try_to_exit_operation.exit_enable = 1 # Atingiu o ponto com o retorno predito
        return -1

    return 0

@static_vars(state=INITIALIZE_STATE, change_state=0, hold_1s=0)
# def foo():
#     foo.counter += 1
#     print "Counter is %d" % foo.counter
#     
def trading_state_machine(day_data, options, loaded):
    
    global g_current_result, g_last_prediction, g_prediction
    global g_current_sample, g_n_ops, g_fp, g_fn, g_tp, g_tn
    global g_reference_prc_enter, g_reference_prc_exit
    global g_current_state

    #print "trading state machine"
    
    enter_flag = 0
    exit_flag = 0
    exited_flag = 0
    reset_flag = 0
    
    if g_current_state == INITIALIZE_STATE:
        g_current_state = BEGIN_PREDICTION_STATE
        if PLOT_GRAPH == 1:
            capital_plot_curvature()
    
    if g_current_state == BEGIN_PREDICTION_STATE:
        #print "BEGIN PRED"
        if loaded == 1:
            for i in range(4):
                g_current_result[i, 0] = calculate_period_return(day_data, options, i)

            pred = choose_best_prediction()
            if pred == 1:
                #save last prediction
                for i in range(4):
                    g_last_prediction[i, 0] = g_prediction[i, 0]

                g_current_sample = sample_previous_period(day_data, options, g_current_sample)
                g_reference_prc_enter, _, _, _, _ = get_symbol_values(day_data, options, g_best_stock_pred_i)

                has_time = calculate_limits_sample_enter_exit(day_data, options)
                trading_state_machine.change_state = 1

                if has_time == 1:
                    trading_state_machine.state = TRY_TO_ENTER_STATE
                    reset_flag = 1
                    g_current_state = PLOT_STATE
                else:
                    trading_state_machine.state = END_STATE
            else:
                trading_state_machine.state = END_STATE
                trading_state_machine.change_state = 1

                for i in range(4):
                    if g_current_result[i, 0] > 0:
                        g_fn[i, 0] += 1
                    elif g_current_result[i, 0] <= 0:
                        g_tn[i, 0] += 1

    if g_current_state == TRY_TO_ENTER_STATE:
        entered = try_to_enter_operation(day_data, options)
        if entered == 1:
            g_reference_prc_exit, _, _, _, _ = get_symbol_values(day_data, options, g_best_stock_pred_i)
            g_n_ops[g_best_stock_pred_i, 0] += 1
            trading_state_machine.state = TRY_TO_EXIT_STATE
            trading_state_machine.change_state = 1
            enter_flag = 1
        if entered == -1:
            trading_state_machine.state = END_STATE
            trading_state_machine.change_state = 1

        g_current_state = PLOT_STATE

    if g_current_state == TRY_TO_EXIT_STATE:
        exited = try_to_exit_operation(day_data, options)
        if exited == 1:
            trading_state_machine.state = PLOT_STATE
            trading_state_machine.change_state = 1
            exited_flag = 1
        elif exited == -1:
            exit_flag = 1
            
        g_current_state = PLOT_STATE
        
    if g_current_state == END_STATE:
        if PLOT_GRAPH == 1:
            capital_plot_curvature()
            # espera 1s para dar pra visualziar melhor o grafico
            if trading_state_machine.hold_1s == 1:
                print ("\n")
                sleep(1)
                trading_state_machine.hold_1s = 0

        trading_state_machine.state = BEGIN_PREDICTION_STATE
        trading_state_machine.change_state = 1
    
    if g_current_state == PLOT_STATE:
        if g_current_sample >= g_last_sample_exit:
            trading_state_machine.state = END_STATE
            trading_state_machine.change_state = 1
            trading_state_machine.hold_1s = 1
 
        #TODO: Fazer uma funcao pra isso
        #TODO: Talvez computar um capital soh e plotar o grafico ao final de cada operacao
        if PLOT_GRAPH == 1:
            current_prc = 0
            delta_prc = 0.0
 
            current_prc, _, _, _, _ = get_symbol_values(day_data, options, g_best_stock_pred_i)
 
            delta_prc = current_prc - g_reference_prc_enter
            prc_plot_curvature(day_data, options, reset_flag, delta_prc, enter_flag, exit_flag, exited_flag)
 
            if exited_flag == 1:
                print("enter=%d exit=%d exited=%d sample=%d "
                        "delta_prc=%.2lf current_prc=%.2lf reference_enter=%.2lf reference_exit=%.2lf "
                        "return=%.2lf" %
                        (enter_flag, exit_flag, exited_flag, g_current_sample,
                        delta_prc, current_prc, g_reference_prc_enter, g_reference_prc_exit,
                        current_prc - g_reference_prc_exit))
            else:
                print("enter=%d exit=%d exited=%d sample=%d "
                        "delta_prc=%.2lf current_prc=%.2lf reference_enter=%.2lf reference_exit=-- "
                        "return=--" %
                        (enter_flag, exit_flag, exited_flag, g_current_sample,
                        delta_prc, current_prc, g_reference_prc_enter))
     
    if trading_state_machine.change_state == 1:
        g_current_state = trading_state_machine.state
    
    return 0

def move_1_tick(day_data, options, loaded):
    
    global g_current_sample
    
    #print g_net_phase, g_net_phase == TEST_PHASE
    
    if g_net_phase == TEST_PHASE:   
        trading_state_machine(day_data, options, loaded)
        if g_current_state == END_STATE:
            if g_current_sample <= g_last_sample:
                g_current_sample = g_last_sample + 1
        else:
            if ( g_current_sample >= g_min_sample and g_current_sample < g_max_sample ):
                g_current_sample += 1
            else:
                g_current_sample = g_min_sample
    else:
        if ( g_current_sample >= g_min_sample and g_current_sample < g_max_sample ):
            g_current_sample += 1
        else:
            g_current_sample = g_min_sample
   
def time_to_start(day_data):

    t = dt.datetime.strptime(day_data.dataset[g_current_sample, day_data.time_id], g_dt_format)

    ret = 0
    if (
        ( t.hour == g_train_time.hour and t.minute >= g_train_time.minute ) or
        ( t.hour > g_train_time.hour ) 
       ) and ( g_current_sample < g_max_sample and g_current_sample >= g_min_sample ):
        ret = 1
    
    return ret
     
def time_to_train(day_data):

    t = dt.datetime.strptime(day_data.dataset[g_current_sample, day_data.time_id], g_dt_format)
    
    ret = 0
    if (
        ( g_current_state != INITIALIZE_STATE ) and 
        (( t.hour < g_train_time.hour ) or ( t.hour == g_train_time.hour and t.minute < g_train_time.minute)) 
       ):
        ret = 1

    if (
        ( ( t.hour == g_train_time.hour and t.minute >= g_train_time.minute ) or
        ( t.hour > g_train_time.hour and t.hour < g_test_time.hour ) or
        ( t.hour == g_test_time.hour and t.minute < g_test_time.minute ) ) and
        g_current_sample < g_max_sample and g_current_sample >= g_min_sample
       ):
        ret = 1

    return ret

def time_to_test(day_data):
    
    t = dt.datetime.strptime(day_data.dataset[g_current_sample, day_data.time_id], g_dt_format)

    ret = 0
    if ( 
        ( g_current_state != INITIALIZE_STATE ) and 
        (( t.hour < g_test_time.hour ) or ( t.hour == g_test_time.hour and t.minute < g_test_time.minute)) 
       ):
        ret = 1

    if (
        ( ( t.hour == g_test_time.hour and t.minute >= g_test_time.minute ) or
          ( t.hour > g_test_time.hour and t.hour < g_test_end_time.hour ) or
          ( t.hour == g_test_end_time.hour and t.minute <= g_test_end_time.minute )
        ) and
        g_current_sample < g_max_sample and g_current_sample >= g_min_sample
       ):
        ret = 1

    return ret

def load_data_input(day_data, options):
    
    sample = g_current_sample
    
    # 4 hardcoded
    input_data = numpy.zeros((4, options.n_in))
    
    #TODO: o preco mais antigo ta na ultima posicao e o preco mais novo na posicao 0
    for i in range(0, options.n_in):
        sample = sample_previous_period(day_data, options, sample)    
        if sample < 0:
            return None

        input_data[0, i] = day_data.dataset[sample, day_data.win_id + day_data.mid_id]
        input_data[1, i] = day_data.dataset[sample, day_data.ind_id + day_data.mid_id]
        input_data[2, i] = day_data.dataset[sample, day_data.wdo_id + day_data.mid_id]
        input_data[3, i] = day_data.dataset[sample, day_data.dol_id + day_data.mid_id]
        
    for i in range(0, options.n_in):
        input_data[0, i] -= input_data[0, options.n_in - 1]
        input_data[1, i] -= input_data[1, options.n_in - 1]
        input_data[2, i] -= input_data[2, options.n_in - 1]
        input_data[3, i] -= input_data[3, options.n_in - 1]
    
    return input_data

def load_input(day_data, options):
    
    current_time = dt.datetime.strptime(day_data.dataset[g_current_sample, day_data.time_id], g_dt_format)
    last_time = dt.datetime.strptime(day_data.dataset[g_last_sample, day_data.time_id], g_dt_format)
            
    ret = 0
    input_data = None
    
    if (current_time - last_time).total_seconds() >= options.period:
        input_data = load_data_input(day_data, options)
        if input_data is None:
            ret = 0
        else:
            ret = 1 
    else:
        ret = 0
    
    return ret, input_data

def load_output(day_data, options):
    
    global g_last_sample

    output_data = numpy.zeros((4, 1))

    for i in range(4):
        output_data[i, 0] = calculate_period_return(day_data, options, i)

    g_last_sample = g_current_sample;

    return output_data

def train_model(model, input_data, output_data):    

    epochs = 100
#     if g_net_phase == TRAIN_PHASE:
#         epochs = 100
#     else:
#         epochs = 4
        
    earlyStopping = EarlyStopping(monitor='loss', min_delta=0, patience=2, verbose=0, mode='auto')
    #input_data = numpy.reshape(input_data, (1, input_data.shape[0]))
    #output_data = numpy.reshape(output_data, (output_data.shape[1], output_data.shape[0]))
    
    #for i in range(4):
    #    print "Epoch= " + str(i)
    model.fit(input_data, output_data, nb_epoch=epochs, batch_size=1, verbose=0, shuffle=False, callbacks=[earlyStopping])
#    model.train_on_batch(input_data, output_data)

    return model

def calculate_hit_rate(y, t):
    
    hits = 0
    miss = 0
    for i in range(0, len(y)):       
        if y[i] > 0 and t[i] > 0:
            hits += 1
        elif y[i] <= 0 and t[i] <= 0:
            hits += 1
        else:
            miss += 1
        
    return hits, miss
   
def signal_of_val(val):
    
    if val > 0.0:
        return 0
    elif val < 0.0:
        return 1
    else:
        return 2
  
def r_sum(stock, signal):

    sumv = 0
    for back_added in range(g_running_sum_size):
        if ((g_sample_statistics - back_added) >= 0):
            sumv += g_results[g_sample_statistics - back_added, stock, signal]

    return sumv


def f_sum(stock, parameter):

    sumv = 0

    for i in range(g_sample_statistics):
        sumv += g_results[i, stock, parameter]

    return sumv

def compute_prediction_statistics(output_data):
    
    global g_sample_statistics, g_results, g_confidence
    global g_mean_correct_positive_pred, g_mean_reverse_positive_pred
    global g_mean_correct_negative_pred, g_mean_reverse_negative_pred
    
    sample = g_sample_statistics
    g_sample_statistics += 1

    for stock in range(4):
        
        pred_ret = g_prediction[stock, 0]
        actu_ret = output_data[stock, 0]

        if (sample > 0):
            s1 = signal_of_val(g_results[sample - 1, stock, P_RETURN])
            s2 = signal_of_val(g_results[sample - 1, stock, RETURN])

            #print("s1=%d s2=%d" % (s1, s2))

            if ((s1 == SUBIU) and (s2 == SUBIU)):
                g_results[sample, stock, SS] += 1
            elif ((s1 == SUBIU) and (s2 == DESCE)):
                g_results[sample, stock, SD] += 1
            elif ((s1 == SUBIU) and (s2 == NEUTR)):
                g_results[sample, stock, SN] += 1
            elif ((s1 == DESCE) and (s2 == SUBIU)):
                g_results[sample, stock, DS] += 1
            elif ((s1 == DESCE) and (s2 == DESCE)):
                g_results[sample, stock, DD] += 1
            elif ((s1 == DESCE) and (s2 == NEUTR)):
                g_results[sample, stock, DN] += 1
            elif ((s1 == NEUTR) and (s2 == SUBIU)):
                g_results[sample, stock, NS] += 1
            elif ((s1 == NEUTR) and (s2 == DESCE)):
                g_results[sample, stock, ND] += 1
            elif ((s1 == NEUTR) and (s2 == NEUTR)):
                g_results[sample, stock, NN] += 1

            sumv = r_sum(stock, SS) + r_sum(stock, SD) + r_sum(stock, SN)
            if (sumv != 0):
                g_mean_correct_positive_pred[stock, 0] = 100.0 * (3.0 * r_sum(stock, SS) - 3.0 * r_sum(stock, SD) - r_sum(stock, SN)) / (3.0 * sumv)

                g_mean_reverse_positive_pred[stock, 0] = 100.0 * (3.0 * r_sum(stock, SD) - 3.0 * r_sum(stock, SS) - r_sum(stock, SN)) / (3.0 * sumv)
            else:
                g_mean_correct_positive_pred[stock, 0] = -100.0
                g_mean_reverse_positive_pred[stock, 0] = -100.0

            sumv = r_sum(stock, DD) + r_sum(stock, DS) + r_sum(stock, DN)
            if (sumv != 0):
                g_mean_correct_negative_pred[stock, 0] = 100.0 * (3.0 * r_sum(stock, DD) - 3.0 * r_sum(stock, DS) - r_sum(stock, DN)) / (3.0 * sumv)

                g_mean_reverse_negative_pred[stock, 0] = 100.0 * (3.0 * r_sum(stock, DS) - 3.0 * r_sum(stock, DD) - r_sum(stock, DN)) / (3.0 * sumv)
                
            else:
                g_mean_correct_negative_pred[stock, 0] = -100.0
                g_mean_reverse_negative_pred[stock, 0] = -100.0

        g_results[sample, stock, P_RETURN] = pred_ret
        g_results[sample, stock, RETURN] = actu_ret
  
        # copy confidence
        g_confidence[stock, 0] = g_mean_correct_positive_pred[stock, 0]
        g_confidence[stock, 1] = g_mean_correct_positive_pred[stock, 0]
  
def reset_statistics():

    global g_capital, g_buy_sell_count
    global g_results, g_n_ops
    global g_n_hits, g_n_miss
    global g_prediction, g_last_prediction
    global g_confidence, g_tp, g_tn, g_fp, g_tn
    global g_current_result, g_current_sample
    global g_min_sample, g_max_sample
    global g_sample_statistics, g_last_sample
    global g_last_sample_enter, g_last_sample_exit
    global g_current_state
    
    for j in range(4):
        g_capital[j, 0] = 125000.0
        g_buy_sell_count[j, 0] = 0
        for k in range(MAX_DATA_SAMPLES):
            for i in range(13):
                g_results[k, j, i] = 0

        g_n_ops[j, 0] = 0
        g_n_hits[j, 0] = 0
        g_n_miss[j, 0] = 0
        g_prediction[j, 0] = 0.0
        g_last_prediction[j, 0] = 0.0
        g_confidence[j, 0] = 0.0
        g_confidence[j, 1] = 0.0

        g_current_result[j, 0] = 0
        g_tp[j, 0] = 0
        g_tn[j, 0] = 0
        g_fp[j, 0] = 0
        g_fn[j, 0] = 0

    g_capital[4, 0] = 125000.0
    g_capital[4, 0] = 125000.0

    g_sample_statistics = 0;

    g_current_sample = 0
    g_min_sample = 0
    g_last_sample = 0
    g_last_sample_enter = 0
    g_last_sample_exit = 0
    g_current_state = INITIALIZE_STATE

def show_statistics(day_data, options):

    current_time = dt.datetime.strptime(day_data.dataset[g_current_sample, day_data.time_id], g_dt_format)
    print current_time
    
    for stock in range(4):

        total_tested = 0
        for k in range(g_running_sum_size):
            for i in range(9):
                if ((g_current_sample - k) >= 0):
                    total_tested += g_results[k, stock, i]

        if total_tested > 0:
            if stock == 0:
                print("WIN: "),
            if stock == 1:
                print("IND: "),
            if stock == 2:
                print("WDO: "),
            if stock == 3:
                print("DOL: "),

            for i in range(9):
                ch1 = ' '
                ch2 = ' '

                if ((i == 0) or (i == 1) or (i == 2)): 
                    ch1 = 'i'
                if ((i == 3) or (i == 4) or (i == 5)):
                    ch1 = '!'
                if ((i == 6) or (i == 7) or (i == 8)):
                    ch1 = '-'

                if ((i == 0) or (i == 3) or (i == 6)): 
                    ch2 = 'i'
                if ((i == 1) or (i == 4) or (i == 7)):
                    ch2 = '!'
                if ((i == 2) or (i == 5) or (i == 8)):
                    ch2 = '-'

                print ("%c%c = %5.2lf, " % (ch1, ch2, 100.0 * r_sum(stock, i) / total_tested)),
            
            print ("== = %6.2lf:  " % (100.0 * (r_sum(stock, SS) + r_sum(stock, DD) + r_sum(stock, NN)) / total_tested)),

            sumv = r_sum(stock, SS) + r_sum(stock, SD) + r_sum(stock, SN)
            if (sumv != 0):
                print("gi %6.1lf  " % (100.0 * (3.0 * r_sum(stock, SS) - 3.0 * r_sum(stock, SD) - r_sum(stock, SN)) / (3.0 * sumv))),
            else:
                print("gi   ---   "),

            sumv = r_sum(stock, DD) + r_sum(stock, DS) + r_sum(stock, DN)
            if (sumv != 0):
                print ("g! %6.1lf  " % (100.0 * (3.0 * r_sum(stock, DD) - 3.0 * r_sum(stock, DS) - r_sum(stock, DN)) / (3.0 * sumv))),
            else:
                print ("g!   ---  "),

            if g_buy_sell_count[stock, 0]  > 0:
                print ("buy_sell_count = %2d, capital = %.2lf, return = %.4lf, p_return = %.4lf, invest = %d, hit_rate = %6.1lf" %
                        ( g_buy_sell_count[stock, 0], g_capital[stock, 0],
                        g_results[g_sample_statistics-1, stock, RETURN], g_results[g_sample_statistics-1, stock, P_RETURN],
                        g_results[g_sample_statistics-1, stock, INVEST],
                        100.0 * f_sum(stock, HITS) / (g_buy_sell_count[stock, 0])))
            else:
                print("buy_sell_count = %2d, capital = %.2lf, return = %.4lf, p_return = %.4lf, invest = %d, hit_rate = --- " %
                        (g_buy_sell_count[stock, 0], g_capital[stock, 0],
                        g_results[g_sample_statistics-1, stock, RETURN], g_results[g_sample_statistics-1, stock, P_RETURN],
                        g_results[g_sample_statistics-1, stock, INVEST]))

    total_capital = 0.0
    total_buy_sell = 0
    for stock in range(4):
        total_capital += g_capital[stock, 0]
        total_buy_sell += g_buy_sell_count[stock, 0]

    print ("num_periods_with_operations = %d, total_buy_sell = %d, average_final_capital = %.2lf\n" %
            (total_tested, total_buy_sell, total_capital / 4))

def show_statistics_exp(day_i):

    global g_stat_day
    
    total_hits = 0

    for stock in range(4):
        total_tested = 0
        for i in range(9):
            total_tested += f_sum(stock, i)

        if total_tested > 0:
            for i in range(9):
                
                g_stat_day[day_i, stock, i] =  100.0 * f_sum(stock, i) / total_tested

            g_stat_day[day_i, stock, ACC] = 100.0 * (f_sum(stock, SS) + f_sum(stock, DD) + f_sum(stock, NN)) / total_tested

            sumv = f_sum(stock, SS) + f_sum(stock, SD) + f_sum(stock, SN)
            if sumv != 0:
                g_stat_day[day_i, stock, GI] = 100.0 * (3.0 * f_sum(stock, SS) - 3.0 * f_sum(stock, SD) - f_sum(stock, SN)) / (3.0 * sumv)
            else:
                g_stat_day[day_i, stock, GI] = 0.0

            sumv = f_sum(stock, DD) + f_sum(stock, DS) + f_sum(stock, DN)
            if sum != 0:
                g_stat_day[day_i, stock, Gi] = 100.0 * (3.0 * f_sum(stock, DD) - 3.0 * f_sum(stock, DS) - f_sum(stock, DN)) / (3.0 * sumv)
            else:
                g_stat_day[day_i, stock, Gi] = 0.0

            if g_buy_sell_count[stock, 0] > 0:
                g_stat_day[day_i, stock, HITS] = f_sum(stock, HITS)
                total_hits += g_stat_day[day_i, stock, HITS]
            else:
                g_stat_day[day_i, stock, HITS] = 0.0

    #--------------- capital day

    total_capital = 0.0
    total_buy_sell = 0
    symbol = "" 
    for stock in range(4):
        total_capital += g_capital[stock, 0]
        total_buy_sell += g_buy_sell_count[stock, 0]

    stat_exp_day = statistics_exp()
    
    stat_exp_day.day = day_i
    stat_exp_day.avg_capital = total_capital / 4.0
    stat_exp_day.geral_capital = g_capital[4, 0]
    stat_exp_day.n_ops = total_buy_sell
    stat_exp_day.total_hits = total_hits

    print ("day_i=%d; avg_capital=%.2lf; geral_capital=%.2lf; n_ops=%d; hit_rate=%.1lf; " %
            (day_i, stat_exp_day.avg_capital, stat_exp_day.geral_capital, stat_exp_day.n_ops,
            100.0 * stat_exp_day.total_hits / stat_exp_day.n_ops)),

    for stock in range(4):

        if stock == 0:
            symbol = "WIN_"
        elif stock == 1: 
            symbol = "IND_"
        elif stock == 2:
            symbol = "WDO_"
        elif stock == 3:
            symbol = "DOL_"

        for i in range(9):
            ch1 = ' '
            ch2 = ' '

            if ((i == 0) or (i == 1) or (i == 2)):
                ch1 = 'i'
            if ((i == 3) or (i == 4) or (i == 5)):
                ch1 = '!'
            if ((i == 6) or (i == 7) or (i == 8)):
                ch1 = '-'

            if ((i == 0) or (i == 3) or (i == 6)):
                ch2 = 'i'
            if ((i == 1) or (i == 4) or (i == 7)):
                ch2 = '!'
            if ((i == 2) or (i == 5) or (i == 8)):
                ch2 = '-'

            print ("%s%c%c=%.2lf; " % (symbol, ch1, ch2, g_stat_day[day_i, stock, i])),

        print ("%s===%.2lf; " % (symbol, g_stat_day[day_i, stock, ACC])),
        print ("%sgi=%.1lf; " % (symbol, g_stat_day[day_i, stock, GI])),
        print ("%sg!=%.1lf; " % (symbol, g_stat_day[day_i, stock, Gi])),
               
        if g_buy_sell_count[stock, 0] > 0:
            print ("%shit_rate=%.1lf; " % (symbol,  100.0 * g_stat_day[day_i, stock, HITS] / g_buy_sell_count[stock, 0])),
        else:
            print ("%shit_rate=--; " % (symbol)),

        print ("%scapital=%.1lf; " % (symbol,  g_capital[stock, 0])),
        print ("%sn_ops=%d; " % (symbol,  g_buy_sell_count[stock, 0])),
    print("\n")

    stat_exp_day.capital_win = g_capital[0, 0]
    stat_exp_day.capital_ind = g_capital[1, 0]
    stat_exp_day.capital_wdo = g_capital[2, 0]
    stat_exp_day.capital_dol = g_capital[3, 0]

    stat_exp_day.n_ops_win = g_buy_sell_count[0, 0]
    stat_exp_day.n_ops_ind = g_buy_sell_count[1, 0]
    stat_exp_day.n_ops_wdo = g_buy_sell_count[2, 0]
    stat_exp_day.n_ops_dol = g_buy_sell_count[3, 0]
    
    return stat_exp_day

def mean_statistics_exp(day_i):

    n = 1.0 * day_i

    total_capital = 0.0
    total_geral_capital = 0.0
    total_capital_win = 0.0
    total_capital_ind = 0.0
    total_capital_wdo = 0.0
    total_capital_dol = 0.0

    total_hits = 0.0

    n_ops = 0
    n_ops_win = 0
    n_ops_ind = 0
    n_ops_wdo = 0
    n_ops_dol = 0

    mean_stat_day = numpy.zeros((4, 13))

    for i in range(day_i):
        total_capital    += g_stat_exp[i].avg_capital
        total_geral_capital    += g_stat_exp[i].geral_capital
        total_capital_win += g_stat_exp[i].capital_win
        total_capital_ind += g_stat_exp[i].capital_ind
        total_capital_wdo += g_stat_exp[i].capital_wdo
        total_capital_dol += g_stat_exp[i].capital_dol

        total_hits += g_stat_exp[i].total_hits

        n_ops    += g_stat_exp[i].n_ops
        n_ops_win    += g_stat_exp[i].n_ops_win
        n_ops_ind    += g_stat_exp[i].n_ops_ind
        n_ops_wdo    += g_stat_exp[i].n_ops_wdo
        n_ops_dol    += g_stat_exp[i].n_ops_dol

        for stock in range(4):
            for j in range(13):
                mean_stat_day[stock, j] += g_stat_day[i, stock, j]

    print ("day_i=Mean; avg_capital=%.2lf; avg_geral_capital=%.2lf; n_ops=%.2lf; hit_rate=%.1lf; " %
            (total_capital / n, total_geral_capital / n, (1.0 * n_ops) / n, 100.0 * total_hits / n_ops)),
            
    symbol = ""
    for stock in range(4):
        if stock == 0:
            symbol = "WIN_"
        elif stock == 1: 
            symbol = "IND_"
        elif stock == 2:
            symbol = "WDO_"
        elif stock == 3:
            symbol = "DOL_"

        for j in range(9):
            ch1 = ' '
            ch2 = ' '

            if ((j == 0) or (j == 1) or (j == 2)):
                ch1 = 'i'
            if ((j == 3) or (j == 4) or (j == 5)):
                ch1 = '!'
            if ((j == 6) or (j == 7) or (j == 8)):
                ch1 = '-'

            if ((j == 0) or (j == 3) or (j == 6)):
                ch2 = 'i'
            if ((j == 1) or (j == 4) or (j == 7)):
                ch2 = '!'
            if ((j == 2) or (j == 5) or (j == 8)):
                ch2 = '-'

            print ("%s%c%c=%.2lf; " % (symbol, ch1, ch2, mean_stat_day[stock, j] / n)),

        print ("%s===%.2lf; " % (symbol, mean_stat_day[stock, ACC] / n)),
        print ("%sgi=%.1lf; " % (symbol, mean_stat_day[stock, GI] / n)),
        print ("%sg!=%.1lf; " % (symbol, mean_stat_day[stock, Gi] / n)),

        if stock == 0:
            if n_ops_win > 0:
                print ("%shit_rate=%.1lf; " % (symbol,  100.0 * mean_stat_day[stock, HITS] / n_ops_win)),
            else:
                print ("%shit_rate=--; " % (symbol)),
            print ("%scapital=%.2lf; %sn_ops=%.2lf; " % (symbol, total_capital_win / n, symbol, (1.0 * n_ops_win) / n)),

        if stock == 1:
            if n_ops_ind > 0: 
                print ("%shit_rate=%.1lf; " % (symbol,  100.0 * mean_stat_day[stock, HITS] / n_ops_ind)),
            else:
                print ("%shit_rate=--; " % (symbol)), 
            print ("%scapital=%.2lf; %sn_ops=%.2lf; " % (symbol, total_capital_ind / n, symbol, (1.0 * n_ops_ind) / n)),
            
        if stock == 2:
            if n_ops_wdo > 0: 
                print ("%shit_rate=%.1lf; " % (symbol,  100.0 * mean_stat_day[stock, HITS] / n_ops_wdo)),
            else:
                print ("%shit_rate=--; " % (symbol)),
            print ("%scapital=%.2lf; %sn_ops=%.2lf; " % (symbol, total_capital_wdo / n, symbol, (1.0 * n_ops_wdo) / n)),

        if stock == 3:
            if n_ops_dol > 0:
                print ("%shit_rate=%.1lf; " % (symbol,  100.0 * mean_stat_day[stock, HITS] / n_ops_dol)),
            else:
                print("%shit_rate=--; " % (symbol)),
            print ("%scapital=%.2lf; %sn_ops=%.2lf; " % (symbol, total_capital_dol / n, symbol, (1.0 * n_ops_dol) / n)),      
    print("\n")

def print_capital():

    acc = 0.0
    total_hits = 0
    total_miss = 0
    total_ops = 0;
    total_longs = 0
    predc = 0.0
    recall = 0.0

    for i in range(4):
        total_hits += g_n_hits[i, 0]
        total_miss += g_n_miss[i, 0]
        total_ops  += g_n_ops[i, 0]
        total_longs += g_buy_sell_count[i, 0]

        if g_n_ops[i, 0] > 0:
            acc = (100.0 * g_n_hits[i, 0]) / g_n_ops[i, 0]
            print ("capital[%d]=%.2lf longs=%d ops=%d hits=%d miss=%d acc=%.1lf" %
                   (i, g_capital[i, 0], g_buy_sell_count[i, 0], 
                    g_n_ops[i, 0], g_n_hits[i, 0], g_n_miss[i, 0], acc))
        else:
            print ("capital[%d]=%.2lf longs=%d ops=%d hits=%d miss=%d acc=--" %
                   (i, g_capital[i, 0], g_buy_sell_count[i, 0], 
                    g_n_ops[i, 0], g_n_hits[i, 0], g_n_miss[i, 0]))
            

        if (g_tp[i, 0] + g_fp[i, 0]) > 0:
            predc = 100.0 * g_tp[i, 0] / (g_tp[i, 0] + g_fp[i, 0])
            recall = 100.0 * g_tp[i, 0] / (g_tp[i, 0] + g_fn[i, 0])

            print ("tp=%1.1lf fp=%1.1lf tn=%1.1lf fn=%1.1lf predc=%.2lf rec=%.2lf" % 
                   (g_tp[i, 0], g_fp[i, 0], g_tn[i, 0], g_fn[i, 0], predc, recall))
        else:
            print ("tp=%1.1lf fp=%1.1lf tn=%1.1lf fn=%1.1lf predc=-- rec=--" % 
                   (g_tp[i, 0], g_fp[i, 0], g_tn[i, 0], g_fn[i, 0]))

    if total_ops > 0:
        acc = (100.0 * total_hits) / total_ops
        print ("capital[%d]=%.2lf longs=%d ops=%d hits=%d miss=%d acc=%.1lf" %
               (4, g_capital[4, 0], total_longs, 
                total_ops, total_hits, total_miss, acc))
    else:
        print ("capital[%d]=%.2lf longs=%d ops=%d hits=%d miss=%d acc=--" %
               (4, g_capital[4, 0], total_longs, 
                total_ops, total_hits, total_miss))

def calculate_u_theil(t, y):
    
    num = 0
    den = 0
        
    for i in range(0, len(t)):
        num += (t[i] - y[i]) * (t[i] - y[i])
        
    for i in range(len(t) - 1):
        den += (t[i] - t[i+1]) * (t[i] - t[i+1])
    
    if den > 0:
        return num / den
    else:
        return -1

def calculate_pocid(t, y):
    
    d = 0

    for i in range(1, len(t)):
        if (t[i] - t[i-1])*(y[i] - y[i-1]) > 0:
            d += 1
      
    return 100.0 * d / len(t)

def calculate_arv(t, y):
    
    mean_t = numpy.mean(t)
    num = 0
    den = 0

    for i in range(0, len(t)):
        num += (y[i] - t[i]) * (y[i] - t[i])
        den += (y[i] - mean_t) * (y[i] - mean_t)
        
    if den > 0:
        return (1.0 / len(t)) * (num / den)
    else:
        return -1
 
def calculate_metrics(t, y):

    for i in range(4):
        if i == 0:
            print "WIN ",
        elif i == 1:
            print "IND ",
        elif i == 2:
            print "WDO ",
        else:
            print "DOL ",
        testTheil = calculate_u_theil(t[i, :], y[i, :])
        print ('Test U Theil= %.6lf ' % (testTheil)),
        testPocid = calculate_pocid(t[i, :], y[i, :])
        print ('Test POCID= %.6lf ' % (testPocid)),
        testArv = calculate_arv(t[i, :], y[i, :])
        print ('Test ARV= %.6lf' % (testArv))

   
def save_predicted_values(t, y):
    f = open("nn_train_10_8_1_t1_sample.csv", "w+")
    f.write("WIN_T; WIN_Y; IND_T; IND_Y; WDO_T; WDO_Y; DOL_T; DOL_Y\n")

    for i in range(len(t[0, :])):
        line = "%lf; %lf; %lf; %lf; %lf; %lf; %lf; %lf\n" % (t[0, i], 
            y[0, i], t[1, i], y[1, i], t[2, i], y[2, i], t[3, i], y[3, i])
        f.write(line)
        
    f.close()
    
def main():
    
    global g_prediction, g_net_phase, g_stat_exp
    
    # parse command-line
    parser = OptionParser()
    (options, args) = parse_cmdline(parser)
    
    day_i = 0
    n_days = 1#len(day_data_names)
    loaded = 0
    
    first_time = 1
    n_neurons = 8
    while day_i < n_days:
        
        #time_steps = options.n_in
        batch_size = 1
        #features = 1
        
        # create model
        model_win = Sequential()
        #model.add(LSTM(4, batch_input_shape=(batch_size, time_steps, features), stateful=True))
        model_win.add(Dense(n_neurons, input_dim=options.n_in, activation='tanh'))
        model_win.add(Dense(1))
        model_win.compile(loss='mse', optimizer='adam')
        
        model_ind = Sequential()
        #model.add(LSTM(4, batch_input_shape=(batch_size, time_steps, features), stateful=True))
        model_ind.add(Dense(n_neurons, input_dim=options.n_in, activation='tanh'))
        model_ind.add(Dense(1))
        model_ind.compile(loss='mse', optimizer='adam')
        
        model_wdo = Sequential()
        #model.add(LSTM(4, batch_input_shape=(batch_size, time_steps, features), stateful=True))
        model_wdo.add(Dense(n_neurons, input_dim=options.n_in, activation='tanh'))
        model_wdo.add(Dense(1))
        model_wdo.compile(loss='mse', optimizer='adam')
        
        model_dol = Sequential()
        #model.add(LSTM(4, batch_input_shape=(batch_size, time_steps, features), stateful=True))
        model_dol.add(Dense(n_neurons, input_dim=options.n_in, activation='tanh'))
        model_dol.add(Dense(1))
        model_dol.compile(loss='mse', optimizer='adam')
    
        if first_time == 1:
            model_win.summary()
            first_time = 0
            #exit()
            
        reset_statistics()
        
        day_data = load_day(day_i, options)
        
        g_net_phase = TRAIN_PHASE
        
        tick = time_to_start(day_data)
        
        while tick == 0:
            move_1_tick(day_data, options, loaded)
            tick = time_to_start(day_data)
        
        print g_current_sample
        print day_data.dataset[g_current_sample, :]
        
        input_all_data_win = None
        input_all_data_ind = None
        input_all_data_wdo = None
        input_all_data_dol = None
        
        output_all_data = None
        
        while tick != 0:
            loaded, input_data = load_input(day_data, options)
            if loaded == 1:
                #print input_data
                output_data = load_output(day_data, options)
                #print output_data

#                 # LSTM reshape input to be [samples, time steps, features]
#                 #input_data = numpy.reshape(input_data, (input_data.shape[0], input_data.shape[1], features))
                  
                if input_all_data_win is None:
                    input_all_data_win = numpy.copy(input_data[0, :])
                else:
                    input_all_data_win = numpy.row_stack((input_all_data_win, input_data[0, :]))
                    
                if input_all_data_ind is None:
                    input_all_data_ind = numpy.copy(input_data[1, :])
                else:
                    input_all_data_ind = numpy.row_stack((input_all_data_ind, input_data[1, :]))
     
                if input_all_data_wdo is None:
                    input_all_data_wdo = numpy.copy(input_data[2, :])
                else:
                    input_all_data_wdo = numpy.row_stack((input_all_data_wdo, input_data[2, :]))
                     
                if input_all_data_dol is None:
                    input_all_data_dol = numpy.copy(input_data[3, :])
                else:
                    input_all_data_dol = numpy.row_stack((input_all_data_dol, input_data[3, :]))
                    
                if output_all_data is None:
                    output_all_data = numpy.copy(output_data)
                else:
                    output_all_data = numpy.column_stack((output_all_data, output_data))
                    
                # train network
#                 model_win = train_model(model_win, input_data[0, :], output_data[0, :])
#                 model_ind = train_model(model_ind, input_data[1, :], output_data[1, :])
#                 model_wdo = train_model(model_wdo, input_data[2, :], output_data[2, :])
#                 model_dol = train_model(model_dol, input_data[3, :], output_data[3, :])
                
            move_1_tick(day_data, options, loaded)
            
            tick = time_to_train(day_data)
        
#         print input_all_data.shape
        print output_all_data.shape   
        model_win = train_model(model_win, input_all_data_win, output_all_data[0, :])
        model_ind = train_model(model_ind, input_all_data_ind, output_all_data[1, :])
        model_wdo = train_model(model_wdo, input_all_data_wdo, output_all_data[2, :])
        model_dol = train_model(model_dol, input_all_data_dol, output_all_data[3, :])
         
#         trainPredict = model.predict(input_all_data, batch_size=batch_size)
#             
#         hits_train, miss_train = calculate_hit_rate(output_all_data, trainPredict)
#         print ('Train hits= %d miss= %d acc= %.2lf' % (hits_train, miss_train, 100.0 * (float(hits_train) / float(hits_train + miss_train)) ))
# 
#         plt.plot(output_all_data)
#         plt.plot(trainPredict)
#         plt.show()
#         #exit(0)
        print g_current_sample
        print day_data.dataset[g_current_sample, :]
        
        g_net_phase = TEST_PHASE
        
        tick = time_to_test(day_data);
        
        first_test_id = output_all_data.shape[1]
        print first_test_id
        predicted_all_data = None
        
        while tick != 0:
            loaded, input_data = load_input(day_data, options)
         
            if loaded == 1:
                # preditc and copy prediction to global variable
                g_prediction[0, 0] = model_win.predict(numpy.reshape(input_data[0, :], (1, input_data[0, :].shape[0])), batch_size=batch_size)
                g_prediction[1, 0] = model_ind.predict(numpy.reshape(input_data[1, :], (1, input_data[1, :].shape[0])), batch_size=batch_size)
                g_prediction[2, 0] = model_wdo.predict(numpy.reshape(input_data[2, :], (1, input_data[2, :].shape[0])), batch_size=batch_size)
                g_prediction[3, 0] = model_dol.predict(numpy.reshape(input_data[3, :], (1, input_data[3, :].shape[0])), batch_size=batch_size)
#                 g_prediction[0, 0] = numpy.random.uniform(-10, 10)
#                 g_prediction[1, 0] = numpy.random.uniform(-10, 10)
#                 g_prediction[2, 0] = numpy.random.uniform(-1, 1)
#                 g_prediction[3, 0] = numpy.random.uniform(-1, 1)
                
                if predicted_all_data is None:
                    predicted_all_data = numpy.copy(g_prediction)
                else:
                    predicted_all_data = numpy.column_stack((predicted_all_data, g_prediction))
                 
                output_data = load_output(day_data, options)
                 
                compute_prediction_statistics(output_data) 
                 
                # insert data to train
                if input_all_data_win is None:
                    input_all_data_win = numpy.copy(input_data[0, :])
                else:
                    input_all_data_win = numpy.row_stack((input_all_data_win, input_data[0, :]))
                    
                if input_all_data_ind is None:
                    input_all_data_ind = numpy.copy(input_data[1, :])
                else:
                    input_all_data_ind = numpy.row_stack((input_all_data_ind, input_data[1, :]))
     
                if input_all_data_wdo is None:
                    input_all_data_wdo = numpy.copy(input_data[2, :])
                else:
                    input_all_data_wdo = numpy.row_stack((input_all_data_wdo, input_data[2, :]))
                     
                if input_all_data_dol is None:
                    input_all_data_dol = numpy.copy(input_data[3, :])
                else:
                    input_all_data_dol = numpy.row_stack((input_all_data_dol, input_data[3, :]))
                
                output_all_data = numpy.column_stack((output_all_data, output_data))
                 
                show_statistics(day_data, options)
                 
                # train network
#                 model_win = train_model(model_win, numpy.reshape(input_data[0, :], (1, input_data[0, :].shape[0])), output_data[0, :])
#                 model_ind = train_model(model_ind, numpy.reshape(input_data[1, :], (1, input_data[1, :].shape[0])), output_data[1, :])
#                 model_wdo = train_model(model_wdo, numpy.reshape(input_data[2, :], (1, input_data[2, :].shape[0])), output_data[2, :])
#                 model_dol = train_model(model_dol, numpy.reshape(input_data[3, :], (1, input_data[3, :].shape[0])), output_data[3, :])
                model_win = train_model(model_win, input_all_data_win, output_all_data[0, :])
                model_ind = train_model(model_ind, input_all_data_ind, output_all_data[1, :])
                model_wdo = train_model(model_wdo, input_all_data_wdo, output_all_data[2, :])
                model_dol = train_model(model_dol, input_all_data_dol, output_all_data[3, :])
                
            move_1_tick(day_data, options, loaded)
                    
            tick = time_to_test(day_data)
        
        test_all_data = output_all_data[:, first_test_id:output_all_data.shape[1]]
        print test_all_data.shape, predicted_all_data.shape
        hits_test0, miss_test0 = calculate_hit_rate(test_all_data[0, :], predicted_all_data[0, :])
        hits_test1, miss_test1 = calculate_hit_rate(test_all_data[1, :], predicted_all_data[1, :])
        hits_test2, miss_test2 = calculate_hit_rate(test_all_data[2, :], predicted_all_data[2, :])
        hits_test3, miss_test3 = calculate_hit_rate(test_all_data[3, :], predicted_all_data[3, :])
        print hits_test0, miss_test0
        print hits_test1, miss_test1
        print hits_test2, miss_test2
        print hits_test3, miss_test3 
        print ('Test hits= %d miss= %d acc= %.2lf' % (hits_test0, miss_test0, 100.0 * (float(hits_test0) / float(hits_test0 + miss_test0)) ))
        print ('Test hits= %d miss= %d acc= %.2lf' % (hits_test1, miss_test1, 100.0 * (float(hits_test1) / float(hits_test1 + miss_test1)) ))
        print ('Test hits= %d miss= %d acc= %.2lf' % (hits_test2, miss_test2, 100.0 * (float(hits_test2) / float(hits_test2 + miss_test2)) ))
        print ('Test hits= %d miss= %d acc= %.2lf' % (hits_test3, miss_test3, 100.0 * (float(hits_test3) / float(hits_test3 + miss_test3)) ))
         
        calculate_metrics(test_all_data, predicted_all_data)

#         plt.plot(test_all_data[0, :])
#         plt.plot(predicted_all_data[0, :])
#         plt.show()
        
        save_predicted_values(test_all_data, predicted_all_data)
        
        print g_current_sample
        print day_data.dataset[g_current_sample, :]
        
        stat_exp = show_statistics_exp(day_i)
        g_stat_exp.append(stat_exp)
        
        day_i += 1
    
    mean_statistics_exp(day_i)
    print_capital()
    
if __name__ == "__main__":
    main()