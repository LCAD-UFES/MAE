import numpy
import pandas
import matplotlib
import matplotlib.pyplot as plt
import sklearn.metrics

WIN_POINT_VALUE = 0.2
IND_POINT_VALUE = 1.0
WDO_POINT_VALUE = 10.0
DOL_POINT_VALUE = 50.0

WIN_QTY = 50#1
IND_QTY = 10#5
WDO_QTY = 25#1
DOL_QTY = 5

CAPITAL = 125000.0

def calculate_u_theil(t, y):
    
    num = 0
    den = 0
        
    for i in range(len(t) - 1):
        num += ((y[i+1] - t[i+1]) * (y[i+1] - t[i+1])) / ((t[i]) * (t[i]))
        
    for i in range(len(t) - 1):
        den += ((t[i+1] - t[i]) * (t[i+1] - t[i])) / ((t[i]) * (t[i]))
    
    return numpy.sqrt(num / den)

def calculate_pocid(t, y):
    
    d = 0

    for i in range(1, len(t)):
        if (t[i] - t[i-1])*(y[i] - y[i-1]) > 0:
            d += 1
      
    return 100.0 * d / len(t)

def calculate_arv(t, y):
    
    mean_t = numpy.mean(t)
    num = 0
    den = 0

    for i in range(0, len(t)):
        num += (y[i] - t[i]) * (y[i] - t[i])
        den += (y[i] - mean_t) * (y[i] - mean_t)
        
    if den > 0:
        return (1.0 / len(t)) * (num / den)
    else:
        return -1
 
def calculate_hit_rate(t, y):
    
    hits = 0
    miss = 0
    for i in range(0, len(y)):       
        if y[i] > 0 and t[i] > 0:
            hits += 1
        elif y[i] <= 0 and t[i] <= 0:
            hits += 1
        else:
            miss += 1
        
    return hits, miss

def calculate_hit_rate_p(t, y):
    
    hits = 0
    miss = 0
    for i in range(0, len(y)):       
        if y[i] > 0 and t[i] > 0:
            hits += 1
        elif y[i] <= 0 and t[i] > 0:
            miss += 1
        
    return hits, miss

def calculate_hit_rate_n(t, y):
    
    hits = 0
    miss = 0
    for i in range(0, len(y)):       
        if y[i] <= 0 and t[i] <= 0:
            hits += 1
        elif y[i] > 0 and t[i] <= 0:
            miss += 1
        
    return hits, miss

def calculate_rmse(t, y):
    
    mse = 0
    for i in range(0, len(t)):
        mse += (y[i] - t[i]) * (y[i] - t[i])
        
    return numpy.sqrt(mse / len(t))

def calculate_me(t, y):
    
    me = 0
    for i in range(0, len(t)):
        me += (y[i] - t[i])
        
    return me / len(t)

def calculate_mape(t, y):
    
    mape = 0
    for i in range(0, len(t)):
        mape += numpy.abs((t[i] - y[i]) / t[i])
        
    return mape / len(t)

def calculate_metrics(t, y):

    for i in range(4):
        if i == 0:
            print "WIN ",
        elif i == 1:
            print "IND ",
        elif i == 2:
            print "WDO ",
        else:
            print "DOL ",
            
        me = calculate_me(t[:, i], y[:, i])
        print ('ME = %.6f' % (me)),
        rmse = calculate_rmse(t[:, i], y[:, i])
        mse = sklearn.metrics.mean_squared_error(t[:, i], y[:, i])
        print ('RMSE = %.6f %.6f' % (rmse, numpy.sqrt(mse))),
        mape = calculate_mape(t[:, i], y[:, i])
        mape2 = sklearn.metrics.mean_absolute_error(t[:, i], y[:, i])
        print ('MAPE= %.6lf %.6lf' % (mape, mape2)),
        testTheil = calculate_u_theil(t[:, i], y[:, i])
        print ('U Theil= %.6lf ' % (testTheil)),
        testPocid = calculate_pocid(t[:, i], y[:, i])
        print ('POCID= %.6lf%% ' % (testPocid)),
        hits, misses = calculate_hit_rate(t[:, i], y[:, i])
        print ('HR= %.6lf%%' % (1.0*hits/(hits+misses))),
        hits_p, misses_p = calculate_hit_rate_p(t[:, i], y[:, i])
        print ('H+= %.6lf%%' % (1.0*hits_p/(hits_p+misses_p))),
        hits_n, misses_n = calculate_hit_rate_n(t[:, i], y[:, i])
        print ('H-= %.6lf%%' % (1.0*hits_n/(hits_n+misses_n)))


def load_data(filename):

    data = pandas.read_csv(filename, sep=';')
    data = data.values
    return data

def from_contract_points_to_money(v, i):
    
#     if i == 0: #WIN
#         v = 100.0 * (v * WIN_POINT_VALUE * WIN_QTY) / CAPITAL 
#     elif i == 1: #IND
#         v = 100.0 * (v * IND_POINT_VALUE * IND_QTY) / CAPITAL
#     elif i == 2: #WDO
#         v = 100.0 * (v * WDO_POINT_VALUE * WDO_QTY) / CAPITAL
#     else: #DOL
#         v = 100.0 * (v * DOL_POINT_VALUE * DOL_QTY) / CAPITAL

#     for j in range(len(v)):
#         if v[j] > 0:
#             v[j] = 1
#         elif v[j] < 0:
#             v[j] = -1

    return v

def get_target_output(data):
    
    #Values are read in contract points
    #WIN, IND, WDO, DOL
    
    t = from_contract_points_to_money(data[:, 0], 0)
    t = numpy.column_stack((t, from_contract_points_to_money(data[:, 2], 1)))
    t = numpy.column_stack((t, from_contract_points_to_money(data[:, 4], 2)))
    t = numpy.column_stack((t, from_contract_points_to_money(data[:, 6], 3)))
    
    y = from_contract_points_to_money(data[:, 1], 0)
    y = numpy.column_stack((y, from_contract_points_to_money(data[:, 3], 1)))
    y = numpy.column_stack((y, from_contract_points_to_money(data[:, 5], 2)))
    y = numpy.column_stack((y, from_contract_points_to_money(data[:, 7], 3)))
    
    return t, y

def main():
    
#     wnn_data = load_data("Resultados/SBPO2017/nn_ntrain/nn_4_4_1_n_256s_10dias_shuffle.csv")
#     nn_data = load_data("Resultados/SBPO2017/nn_ntrain/nn_4_4_1_n_256s_10dias_shuffle.csv")

#     wnn_data = numpy.random.normal(size=(400, 8))
#     nn_data = numpy.random.normal(size=(400, 8))

    wnn_data = load_data("Resultados/SBPO2017/wnn/ita_ind2_src_10dias_32s_33_32_20.csv")
    nn_data = load_data("Resultados/SBPO2017/nn_ntrain/nn_4_4_1_n_32s_10dias_shuffle.csv")
        
    wnn_t, wnn_y = get_target_output(wnn_data)
    nn_t, nn_y = get_target_output(nn_data)
    
    rw = numpy.zeros((len(wnn_t), 4))
    rw[1:,] = wnn_t[0:-1, ]
    
    rw_err = wnn_t - rw
    wnn_err = wnn_t - wnn_y
    nn_err = nn_t - nn_y 
    
    t_std = numpy.zeros(4)
    t_std[0] = numpy.std(wnn_t[:,0])
    t_std[1] = numpy.std(wnn_t[:,1])
    t_std[2] = numpy.std(wnn_t[:,2])
    t_std[3] = numpy.std(wnn_t[:,3])
    #print t_std
    
    z = numpy.zeros(len(wnn_t))
    print len(z), wnn_t.shape
    
    print "max", numpy.max(wnn_t[:,0]), numpy.max(wnn_t[:,1]), numpy.max(wnn_t[:,2]), numpy.max(wnn_t[:,3])
    print "min", numpy.min(wnn_t[:,0]), numpy.min(wnn_t[:,1]), numpy.min(wnn_t[:,2]), numpy.min(wnn_t[:,3])
    print "std", numpy.std(wnn_t[:,0]), numpy.std(wnn_t[:,1]), numpy.std(wnn_t[:,2]), numpy.std(wnn_t[:,3])
    print "mean", numpy.mean(wnn_t[:,0]), numpy.mean(wnn_t[:,1]), numpy.mean(wnn_t[:,2]), numpy.mean(wnn_t[:,3])
    t_std_v = numpy.zeros((len(wnn_t), 4))
    for i in range(len(wnn_t)):
        t_std_v[i, 0] = t_std[0]
        t_std_v[i, 1] = t_std[1]
        t_std_v[i, 2] = t_std[2]
        t_std_v[i, 3] = t_std[3]
        
#     wnn_max = numpy.max(wnn_t[:, 2])
#     wnn_min = numpy.min(wnn_t[:, 2])
#     
#     wnn_amax = numpy.argmax(wnn_t[:, 2])
#     wnn_amin = numpy.argmin(wnn_t[:, 2])
#     print wnn_max, wnn_min, wnn_amax, wnn_amin
    
    if wnn_t.all() == nn_t.all():
        print "WNN Metrics"
        calculate_metrics(wnn_t, wnn_y)
        print "NN Metrics"
        calculate_metrics(nn_t, nn_y)
        print "RW Metrics"
        calculate_metrics(wnn_t, rw)
        print "RW_ERR Metrics"
        calculate_metrics(wnn_t, rw_err)
        
        #return
    
        #f, axarr = plt.subplots(4, sharex="all", sharey="all")
        #f, axarr = plt.subplots(4, sharex="all")
        for i in range(4):
            if i == 0:
                symbol = "WIN"
            elif i == 1:
                symbol = "IND"
            elif i == 2:
                symbol = "WDO"
            else:
                symbol = "DOL"
                
            plt.plot(wnn_t[:30, i], label="Esperado", c="g")
            plt.plot(nn_y[:30, i], label="MLP", c="r")
            plt.plot(wnn_y[:30, i], label="VG-RAM", c="b")
            plt.legend(prop={"size":12}, loc="upper center", ncol=4)
            plt.xlabel("Intervalos de Tempo na Escala de Tempo t=32s", fontsize=18)
            plt.ylabel("Retorno", fontsize=18)
            plt.figure()
            
#             axarr[i].plot(wnn_t[:50, i], label="Real", c="g")
#             axarr[i].plot(wnn_y[:50, i], label="Pred. VG-RAM", c="b")
#             axarr[i].plot(nn_y[:50, i], label="Pred. MLP", c="r")
            
#             axarr[i].plot(wnn_err[:, i], label="Error VG-RAM", c="r")
#             axarr[i].plot(nn_err[:, i], label="Error FF", c="k")
#             axarr[i].plot(rw_err[:, i], label="Error RW", c="b")
            #axarr[i].plot(rw[:, i], label="Error RW", c="b")
            
#             axarr[i].plot(-2.0 * t_std_v[:, i], c="dimgrey")
#             axarr[i].plot(-1.5 * t_std_v[:, i], c="dimgrey")
# #             axarr[i].plot(-1.0 * t_std_v[:, i], c="dimgrey")
# #             axarr[i].plot(-0.5 * t_std_v[:, i], c="dimgrey")
#             axarr[i].plot(z, c="dimgrey")
# #             axarr[i].plot(0.5 * t_std_v[:, i], c="dimgrey")
# #             axarr[i].plot(1.0 * t_std_v[:, i], c="dimgrey")
#             axarr[i].plot(1.5 * t_std_v[:, i], c="dimgrey")
#             axarr[i].plot(2.0 * t_std_v[:, i], c="dimgrey")
            
            #axarr[i].set_title(symbol)
            #if i == 0:
            #    axarr[i].legend(prop={"size":12}, loc="upper center", ncol=4)
            
           
        #plt.plot(wnn_t[:, 2], label="Target")
        #plt.plot(wnn_y[:, 2], label="WNN")
        #plt.plot(nn_t[:, 2], label="NN")
        #f.subplots_adjust(hspace=0.1)
        #plt.setp([a.get_xticklabels() for a in f.axes[:-1]], visible=False)
        #plt.xlabel("Amostra de Tempo na Escala T = 32s", fontsize=18)
        #plt.ylabel("Pontos de Contrato", fontsize=18)
        #axarr[2].set_ylabel("Pontos de Contrato", fontsize=18)
        plt.show()
    else:
        print "WNN target differ from NN target"
    
    return 0

if __name__ == "__main__":
    main()