import numpy
import matplotlib.pyplot as plt
import pandas
#import math
from keras.callbacks import EarlyStopping
from keras.models import Sequential
from keras.layers.core import Dense
import keras.optimizers
#from keras.layers.core import Activation, Dense
#from keras.layers import LSTM
#from sklearn.preprocessing import MinMaxScaler
#from sklearn.metrics import mean_squared_error
import time
import datetime as dt

from optparse import OptionParser

# defines
TRAIN_PHASE = 1
TEST_PHASE = 2

USE_COST = 1

COST_QTY_WIN_WDO = 0.61 
COST_QTY_IND_DOL = 4.43 
WIN_POINT_VALUE = 0.2
IND_POINT_VALUE = 1.0
WDO_POINT_VALUE = 10.0
DOL_POINT_VALUE = 50.0

WIN_QTY = 50#1
IND_QTY = 10#5
WDO_QTY = 25#1
DOL_QTY = 5

COST_WIN_R = (COST_QTY_WIN_WDO * WIN_QTY)
COST_IND_R = (COST_QTY_IND_DOL * IND_QTY)
COST_WDO_R = (COST_QTY_WIN_WDO * WDO_QTY)
COST_DOL_R = (COST_QTY_IND_DOL * DOL_QTY)

CERTAINTY = 65.0

MAX_DATA_SAMPLES = 43200
SS = 0
SD = 1
SN = 2
DS = 3
DD = 4
DN = 5
NS = 6
ND = 7
NN = 8

RETURN = 9
P_RETURN = 10
INVEST = 11
HITS = 12

ACC = 9
GI = 10
Gi = 11

SUBIU = 0
DESCE = 1
NEUTR = 2

MAX_DAYS = 200

# globals g_*
g_net_phase = TRAIN_PHASE 
g_current_result = numpy.zeros((4, 1))
g_last_prediction = numpy.zeros((4, 1))
g_prediction = numpy.zeros((4, 1))
g_confidence = numpy.zeros((4, 2))
g_n_ops = numpy.zeros((4, 1))
g_fn = numpy.zeros((4, 1))
g_fp = numpy.zeros((4, 1))
g_tp = numpy.zeros((4, 1))
g_tn = numpy.zeros((4, 1))
g_n_hits = numpy.zeros((4, 1))
g_n_miss = numpy.zeros((4, 1))
g_buy_sell_count = numpy.zeros((4, 1))
g_capital = numpy.zeros((5, 1)) # pos 5 in general capital
g_results = numpy.zeros((MAX_DATA_SAMPLES, 4, 13))
g_best_stock_pred_i = 0
g_reference_prc_enter = 0
g_reference_prc_exit = 0
g_last_sample_enter = 0
g_last_sample_exit = 0
g_sample_statistics = 0
g_current_sample = 0
g_max_sample = 0
g_min_sample = 0
g_last_sample = 0
g_running_sum_size = 20 #PARAM
g_mean_correct_positive_pred = numpy.zeros((4, 1))
g_mean_reverse_positive_pred = numpy.zeros((4, 1))
g_mean_correct_negative_pred = numpy.zeros((4, 1))
g_mean_reverse_negative_pred = numpy.zeros((4, 1))
g_stat_day = numpy.zeros((MAX_DAYS, 4, 13))
g_stat_exp = []
g_n_samples_train = 0
    
g_dt_format = " %Y-%m-%d %H:%M:%S.%f BRT"
g_train_time = dt.datetime.strptime("09:30:00.0", "%H:%M:%S.%f")
g_test_time = dt.datetime.strptime("13:30:00.0", "%H:%M:%S.%f")
g_test_end_time = dt.datetime.strptime("17:30:00.0", "%H:%M:%S.%f")

class statistics_exp:
    def __init__(self):
        self.day = 0
        self.avg_capital = 0
        self.geral_capital = 0 
        self.n_ops = 0
        self.total_hits = 0
        self.capital_win = 0
        self.n_ops_win = 0
        self.capital_ind = 0
        self.n_ops_ind = 0
        self.capital_wdo = 0
        self.n_ops_wdo = 0
        self.capital_dol = 0
        self.n_ops_dol = 0    
        
class ddata:
    def __init__(self):
        self.dataset = [] #tupla (a, b, c)
        
        self.sample_id = 0
        self.time_id = 1
        
        self.win_id = 2
        self.ind_id = 5
        self.wdo_id = 8
        self.dol_id = 11
        
        self.ask_id = 0
        self.bid_id = 1
        self.mid_id = 2
        
        #self.symbol_name = "NONE"

    def skip_pre_open(self):
        dataset = self.dataset
        for i in range(0, len(dataset)):
            if dataset[i, self.win_id:-1].all() != 0:
                break
        self.dataset = dataset[i:,]
        
def parse_cmdline(parser):
    parser.set_defaults(data_fname="../data_test.txt")
    parser.set_defaults(period=256)
    parser.set_defaults(n_in=4)
    parser.set_defaults(n_out=1)

    parser.add_option("-D", "--data_fname", dest="data_fname", help="Data file name")
    parser.add_option("-t", "--days_train", dest="days_train", help="Days to train > 0")
    parser.add_option("-p", "--days_test", dest="days_test", help="Days to test > 0")
    parser.add_option("-s", "--seconds", dest="period", help="Period in seconds > 0")
    parser.add_option("-I", "--n_input", dest="n_in", help="Default 10.")
    parser.add_option("-O", "--n_output", dest="n_out", help="Default 1.")

    (options, args) = parser.parse_args()
    
    if options.period <= 0:
        parser.error("Error: seconds <= 0")

    if options.n_in <= 0 or options.n_out <= 0:
        parser.error("Error: n_in <= 0 or n_out <= 0")
        
    return (options, args)

def static_vars(**kwargs):
    def decorate(func):
        for k in kwargs:
            setattr(func, k, kwargs[k])
        return func
    return decorate

def read_day_data_fname(day_i, options):    
    
    with open(options.data_fname) as fp:
        for i, line in enumerate(fp):
            if i == day_i:
                print line
                break
        
    return line

def load_day_data(filename, options):

    data = ddata()
    
    filename = filename.rstrip("\n")

    sample_time = pandas.read_csv(filename, sep=';', usecols=[0,1])
    sample_time = sample_time.values
    
    win = pandas.read_csv(filename, sep=';', usecols=[2, 3])
    win = win.values
    win = numpy.column_stack((win, (win[:, 0] + win[:, 1]) / 2.0))
    
    ind = pandas.read_csv(filename, sep=';', usecols=[4, 5])
    ind = ind.values
    ind = numpy.column_stack((ind, (ind[:, 0] + ind[:, 1]) / 2.0))
    
    wdo = pandas.read_csv(filename, sep=';', usecols=[6, 7])
    wdo = wdo.values
    wdo = numpy.column_stack((wdo, (wdo[:, 0] + wdo[:, 1]) / 2.0))
    
    dol = pandas.read_csv(filename, sep=';', usecols=[8, 9])
    dol = dol.values
    dol = numpy.column_stack((dol, (dol[:, 0] + dol[:, 1]) / 2.0))
    
    dataset = sample_time
    dataset = numpy.column_stack((dataset, win))
    dataset = numpy.column_stack((dataset, ind))
    dataset = numpy.column_stack((dataset, wdo))
    dataset = numpy.column_stack((dataset, dol))
    
    data.dataset = dataset
    
    #print data.dataset[0, :]
    #data.skip_pre_open()
    #print data.dataset[0, :]

    #update globals
    global g_current_sample, g_max_sample, g_min_sample
    g_current_sample = 0
    g_min_sample = 0
    g_max_sample = len(data.dataset)
    #print g_current_sample, g_min_sample, g_max_sample

    return data

def load_day(day_i, options):
    
    day_fname = read_day_data_fname(day_i, options)
    day_data = load_day_data(day_fname, options)
    return day_data

def sample_previous_period(day_data, options, sample):
    
    initial_time = dt.datetime.strptime(day_data.dataset[sample, day_data.time_id], g_dt_format)

    while sample > g_min_sample:
        current_time = dt.datetime.strptime(day_data.dataset[sample, day_data.time_id], g_dt_format)
        if (initial_time - current_time).total_seconds() >= options.period:
            return sample
        sample -= 1
        
    return -1

def sample_next_period(day_data, options, sample):

    initial_time = dt.datetime.strptime(day_data.dataset[sample, day_data.time_id], g_dt_format)

    while sample < g_max_sample:
        current_time = dt.datetime.strptime(day_data.dataset[sample, day_data.time_id], g_dt_format)
        if (current_time - initial_time).total_seconds() >= options.period:
            return sample
        sample += 1
        
    return -1

def calculate_period_return(day_data, options, idx):
    
    sample = sample_previous_period(day_data, options, g_current_sample)

    data_idx = 0
    cost_pts = 0
    if idx == 0:
        cost_pts = COST_QTY_WIN_WDO / WIN_POINT_VALUE
        data_idx = day_data.win_id + day_data.mid_id
    elif idx == 1:
        cost_pts = COST_QTY_IND_DOL / IND_POINT_VALUE
        data_idx = day_data.ind_id + day_data.mid_id
    elif idx == 2:
        cost_pts = COST_QTY_WIN_WDO / WDO_POINT_VALUE
        data_idx = day_data.wdo_id + day_data.mid_id
    else:
        cost_pts = COST_QTY_IND_DOL / DOL_POINT_VALUE
        data_idx = day_data.dol_id + day_data.mid_id
    
    enter_prc = day_data.dataset[sample, data_idx]
    exit_prc = day_data.dataset[g_current_sample, data_idx]

    if USE_COST == 1:
        val_ret = exit_prc - enter_prc - 2 * cost_pts
    else:
        val_ret = exit_prc - enter_prc

    return val_ret
    
def compute_capital_evolution(output_data):

    global g_n_hits, g_n_miss, g_n_ops
    global g_n_ops, g_tp, g_tn, g_fp, g_fn
    
    for stock in range(4):
        expected_return_pts = g_prediction[stock, 0]
        actual_return_pts = output_data[stock, 0]
        
        point_value = 0.0
        qty = 0

        if stock == 0:
            point_value = WIN_POINT_VALUE
            qty = WIN_QTY
        elif stock == 1:
            point_value = IND_POINT_VALUE
            qty = IND_QTY
        elif stock == 2:
            point_value = WDO_POINT_VALUE
            qty = WDO_QTY
        else:
            point_value = DOL_POINT_VALUE
            qty = DOL_QTY

        result = actual_return_pts * point_value * qty

        if (output_data[stock, 0] > 0 and g_prediction[stock, 0] > 0):
            g_tp[stock, 0] += 1
        elif (output_data[stock, 0] <= 0 and g_prediction[stock, 0] <= 0):
            g_tn[stock, 0] += 1
        elif (output_data[stock, 0] <= 0 and g_prediction[stock, 0] > 0):
            g_fp[stock, 0] += 1
        else:
            g_fn[stock, 0] += 1
        
        if ( ( g_running_sum_size > 0 and expected_return_pts > 0.0 and g_mean_correct_positive_pred[stock, 0] > CERTAINTY ) or
             ( g_running_sum_size == 0 and expected_return_pts > 0.0 ) 
             ):
                
            previous_capital = g_capital[stock, 0]
            g_capital[stock, 0] += result
            g_capital[4, 0] += result

            if g_capital[stock, 0] > previous_capital:
                g_results[g_sample_statistics - 1, stock, HITS] += 1
                g_n_hits[stock, 0] += 1
            else:
                g_n_miss[stock, 0] += 1
            
            g_buy_sell_count[stock, 0] += 1
            g_n_ops[stock, 0] += 1
            g_results[g_sample_statistics - 1, stock, INVEST] = 1
                
        else:
            g_results[g_sample_statistics - 1, stock, INVEST] = 0

def move_1_tick(day_data, options, loaded):
    
    global g_current_sample
    
    if ( g_current_sample >= g_min_sample and g_current_sample < g_max_sample ):
        g_current_sample += 1
    else:
        g_current_sample = g_min_sample
   
def time_to_start(day_data):

    t = dt.datetime.strptime(day_data.dataset[g_current_sample, day_data.time_id], g_dt_format)
    t_time = dt.datetime.time(t)

    g_train_time_t = dt.datetime.time(g_train_time)
    
    #print t, t_time
    #print t_time >= g_train_time_t
    
    ret = 0
    if (
        ( t_time >= g_train_time_t ) and 
        ( g_current_sample < g_max_sample and g_current_sample >= g_min_sample )
        ):
#     if (
#         ( t.hour == g_train_time.hour and t.minute >= g_train_time.minute ) or
#         ( t.hour > g_train_time.hour ) 
#        ) and ( g_current_sample < g_max_sample and g_current_sample >= g_min_sample ):
        ret = 1
        
    return ret
     
def time_to_train(day_data):

    t = dt.datetime.strptime(day_data.dataset[g_current_sample, day_data.time_id], g_dt_format)
    t_time = dt.datetime.time(t)

    g_train_time_t = dt.datetime.time(g_train_time)
    g_test_time_t = dt.datetime.time(g_test_time)
    
    #print t, t_time
    #print t_time >= g_train_time_t, t_time < g_test_time_t
    
    ret = 0

    if (
        ( t_time >= g_train_time_t ) and
        ( t_time < g_test_time_t ) and
        ( g_current_sample < g_max_sample and g_current_sample >= g_min_sample )
       ):
#     if (
#         ( ( t.hour == g_train_time.hour and t.minute >= g_train_time.minute ) or
#         ( t.hour > g_train_time.hour and t.hour < g_test_time.hour ) or
#         ( t.hour == g_test_time.hour and t.minute < g_test_time.minute ) ) and
#         g_current_sample < g_max_sample and g_current_sample >= g_min_sample
#        ):
        ret = 1

    return ret

def time_to_test(day_data):
    
    t = dt.datetime.strptime(day_data.dataset[g_current_sample, day_data.time_id], g_dt_format)
    t_time = dt.datetime.time(t)

    g_test_time_t = dt.datetime.time(g_test_time)
    g_test_end_time_t = dt.datetime.time(g_test_end_time)
    
    #print t, t_time
    #print t_time >= g_test_time_t, t_time < g_test_end_time_t
    
    ret = 0

    if (
        ( t_time >= g_test_time_t ) and
        ( t_time < g_test_end_time_t ) and
        ( g_current_sample < g_max_sample and g_current_sample >= g_min_sample )
       ):
#     if (
#         ( ( t.hour == g_test_time.hour and t.minute >= g_test_time.minute ) or
#           ( t.hour > g_test_time.hour and t.hour < g_test_end_time.hour ) or
#           ( t.hour == g_test_end_time.hour and t.minute <= g_test_end_time.minute )
#         ) and
#         g_current_sample < g_max_sample and g_current_sample >= g_min_sample
#        ):
        ret = 1

    return ret

def load_data_input(day_data, options):
    
    sample = g_current_sample
    
    # 4 hardcoded
    input_data = numpy.zeros((4, options.n_in))
    
    #TODO: o preco mais antigo ta na ultima posicao e o preco mais novo na posicao 0
    for i in range(0, options.n_in):
        sample = sample_previous_period(day_data, options, sample)    
        if sample < 0:
            return None

        input_data[0, i] = day_data.dataset[sample, day_data.win_id + day_data.mid_id]
        input_data[1, i] = day_data.dataset[sample, day_data.ind_id + day_data.mid_id]
        input_data[2, i] = day_data.dataset[sample, day_data.wdo_id + day_data.mid_id]
        input_data[3, i] = day_data.dataset[sample, day_data.dol_id + day_data.mid_id]
    
    # pra nao ficar zero na primeira posicao do dado    
    sample = sample_previous_period(day_data, options, sample)    
    if sample < 0:
        return None
        
    for i in range(0, options.n_in):
#         input_data[0, i] -= input_data[0, options.n_in - 1]
#         input_data[1, i] -= input_data[1, options.n_in - 1]
#         input_data[2, i] -= input_data[2, options.n_in - 1]
#         input_data[3, i] -= input_data[3, options.n_in - 1]
         
        input_data[0, i] -= day_data.dataset[sample, day_data.win_id + day_data.mid_id]
        input_data[1, i] -= day_data.dataset[sample, day_data.ind_id + day_data.mid_id]
        input_data[2, i] -= day_data.dataset[sample, day_data.wdo_id + day_data.mid_id]
        input_data[3, i] -= day_data.dataset[sample, day_data.dol_id + day_data.mid_id]
    
    return input_data

def load_input(day_data, options):
    
    current_time = dt.datetime.strptime(day_data.dataset[g_current_sample, day_data.time_id], g_dt_format)
    last_time = dt.datetime.strptime(day_data.dataset[g_last_sample, day_data.time_id], g_dt_format)
            
    ret = 0
    input_data = None
    
    if (current_time - last_time).total_seconds() >= options.period:
        input_data = load_data_input(day_data, options)
        if input_data is None:
            ret = 0
        else:
            #print input_data
            #exit()
            ret = 1 
    else:
        ret = 0
    
    return ret, input_data

def load_output(day_data, options):
    
    global g_last_sample

    output_data = numpy.zeros((4, 1))

    for i in range(4):
        output_data[i, 0] = calculate_period_return(day_data, options, i)

    g_last_sample = g_current_sample;

    return output_data

def train_model(model, input_data, output_data):    

    n_ep = len(output_data)
    print n_ep
    
    start_time = time.time()
    #earlyStopping = EarlyStopping(monitor='loss', min_delta=0, patience=2, verbose=0, mode='auto')
    #input_data = numpy.reshape(input_data, (1, input_data.shape[0]))
    #output_data = numpy.reshape(output_data, (output_data.shape[1], output_data.shape[0]))
    
    #for i in range(4):
    #    print "Epoch= " + str(i)
    model.fit(input_data, output_data, nb_epoch=n_ep, batch_size=1, verbose=0, shuffle=True)#, callbacks=[earlyStopping])
#    model.train_on_batch(input_data, output_data)

    elapsed_time = time.time() - start_time
    print "Elapsed time= ", elapsed_time
     
    return model

def train_model_batch(model, input_data, output_data):
   
    start_time = time.time()
    
    n = g_n_samples_train
    size_data = len(output_data)
    #print size_data, n
    n_input = input_data[size_data - n:size_data, :]
    n_output = output_data[size_data - n:size_data]
    #print n_input
    #print n_output
    idxs = numpy.random.permutation(n)
    #idxs = range(n)
    #print idxs
        
    for i in range(n):
        j = idxs[i]
        j_in = numpy.reshape(n_input[j, :], (1, n_input[j, :].shape[0]))
        j_out = numpy.reshape(n_output[j], (1, 1))
        #print j_in, j_out
        
        model.train_on_batch(j_in, j_out)

    #exit()
    elapsed_time = time.time() - start_time
    #print "Elapsed time= ", elapsed_time
    
    return model, elapsed_time

# def train_model_batch(model, input_data, output_data):
#    
#     start_time = time.time()
#     
#     n = 4
#     size_data = len(output_data)
#     
#     n_input = input_data[size_data - n:size_data, :]
#     n_output = output_data[size_data - n:size_data]
#     #print n_input
#     #print n_output
#     idxs = numpy.random.permutation(n)
#     #print idxs
#         
#     for i in range(n):
#         j = idxs[i]
#         j_in = numpy.reshape(n_input[j, :], (1, n_input[j, :].shape[0]))
#         j_out = numpy.reshape(n_output[j], (1, 1))
#         #print j_in, j_out
#         
#         model.train_on_batch(j_in, j_out)
# 
#     #exit()
#     elapsed_time = time.time() - start_time
#     #print "Elapsed time= ", elapsed_time
#     
#     return model, elapsed_time
 
def calculate_hit_rate(y, t):
    
    hits = 0
    miss = 0
    for i in range(0, len(y)):       
        if y[i] > 0 and t[i] > 0:
            hits += 1
        elif y[i] <= 0 and t[i] <= 0:
            hits += 1
        else:
            miss += 1
        
    return hits, miss
   
def signal_of_val(val):
    
    if val > 0.0:
        return 0
    elif val < 0.0:
        return 1
    else:
        return 2
  
def r_sum(stock, signal):

    sumv = 0
    for back_added in range(g_running_sum_size):
        if ((g_sample_statistics - back_added) >= 0):
            sumv += g_results[g_sample_statistics - back_added, stock, signal]

    return sumv


def f_sum(stock, parameter):

    sumv = 0

    for i in range(g_sample_statistics):
        sumv += g_results[i, stock, parameter]

    return sumv

def compute_prediction_statistics(output_data):
    
    global g_sample_statistics, g_results, g_confidence
    global g_mean_correct_positive_pred, g_mean_reverse_positive_pred
    global g_mean_correct_negative_pred, g_mean_reverse_negative_pred
    
    sample = g_sample_statistics
    g_sample_statistics += 1

    for stock in range(4):
        
        pred_ret = g_prediction[stock, 0]
        actu_ret = output_data[stock, 0]

        if (sample > 0):
            s1 = signal_of_val(g_results[sample - 1, stock, P_RETURN])
            s2 = signal_of_val(g_results[sample - 1, stock, RETURN])

            #print("s1=%d s2=%d" % (s1, s2))

            if ((s1 == SUBIU) and (s2 == SUBIU)):
                g_results[sample, stock, SS] += 1
            elif ((s1 == SUBIU) and (s2 == DESCE)):
                g_results[sample, stock, SD] += 1
            elif ((s1 == SUBIU) and (s2 == NEUTR)):
                g_results[sample, stock, SN] += 1
            elif ((s1 == DESCE) and (s2 == SUBIU)):
                g_results[sample, stock, DS] += 1
            elif ((s1 == DESCE) and (s2 == DESCE)):
                g_results[sample, stock, DD] += 1
            elif ((s1 == DESCE) and (s2 == NEUTR)):
                g_results[sample, stock, DN] += 1
            elif ((s1 == NEUTR) and (s2 == SUBIU)):
                g_results[sample, stock, NS] += 1
            elif ((s1 == NEUTR) and (s2 == DESCE)):
                g_results[sample, stock, ND] += 1
            elif ((s1 == NEUTR) and (s2 == NEUTR)):
                g_results[sample, stock, NN] += 1

            sumv = r_sum(stock, SS) + r_sum(stock, SD) + r_sum(stock, SN)
            if (sumv != 0):
                g_mean_correct_positive_pred[stock, 0] = 100.0 * (3.0 * r_sum(stock, SS) - 3.0 * r_sum(stock, SD) - r_sum(stock, SN)) / (3.0 * sumv)

                g_mean_reverse_positive_pred[stock, 0] = 100.0 * (3.0 * r_sum(stock, SD) - 3.0 * r_sum(stock, SS) - r_sum(stock, SN)) / (3.0 * sumv)
            else:
                g_mean_correct_positive_pred[stock, 0] = -100.0
                g_mean_reverse_positive_pred[stock, 0] = -100.0

            sumv = r_sum(stock, DD) + r_sum(stock, DS) + r_sum(stock, DN)
            if (sumv != 0):
                g_mean_correct_negative_pred[stock, 0] = 100.0 * (3.0 * r_sum(stock, DD) - 3.0 * r_sum(stock, DS) - r_sum(stock, DN)) / (3.0 * sumv)

                g_mean_reverse_negative_pred[stock, 0] = 100.0 * (3.0 * r_sum(stock, DS) - 3.0 * r_sum(stock, DD) - r_sum(stock, DN)) / (3.0 * sumv)
                
            else:
                g_mean_correct_negative_pred[stock, 0] = -100.0
                g_mean_reverse_negative_pred[stock, 0] = -100.0

        g_results[sample, stock, P_RETURN] = pred_ret
        g_results[sample, stock, RETURN] = actu_ret
  
        # copy confidence
        g_confidence[stock, 0] = g_mean_correct_positive_pred[stock, 0]
        g_confidence[stock, 1] = g_mean_correct_positive_pred[stock, 0]
  
def reset_statistics():

    global g_capital, g_buy_sell_count
    global g_results, g_n_ops
    global g_n_hits, g_n_miss
    global g_prediction, g_last_prediction
    global g_confidence, g_tp, g_tn, g_fp, g_tn
    global g_current_result, g_current_sample
    global g_min_sample, g_max_sample
    global g_sample_statistics, g_last_sample
    global g_last_sample_enter, g_last_sample_exit
    global g_current_state
    
    for j in range(4):
        g_capital[j, 0] = 125000.0
        g_buy_sell_count[j, 0] = 0
        for k in range(MAX_DATA_SAMPLES):
            for i in range(13):
                g_results[k, j, i] = 0

        g_n_ops[j, 0] = 0
        g_n_hits[j, 0] = 0
        g_n_miss[j, 0] = 0
        g_prediction[j, 0] = 0.0
        g_last_prediction[j, 0] = 0.0
        g_confidence[j, 0] = 0.0
        g_confidence[j, 1] = 0.0

        g_current_result[j, 0] = 0
        g_tp[j, 0] = 0
        g_tn[j, 0] = 0
        g_fp[j, 0] = 0
        g_fn[j, 0] = 0

    g_capital[4, 0] = 125000.0
    g_capital[4, 0] = 125000.0

    g_sample_statistics = 0;

    g_current_sample = 0
    g_min_sample = 0
    g_last_sample = 0
    g_last_sample_enter = 0
    g_last_sample_exit = 0

def show_statistics(day_data, options):

    current_time = dt.datetime.strptime(day_data.dataset[g_current_sample, day_data.time_id], g_dt_format)
    print current_time
    
    for stock in range(4):

        total_tested = 0
        for k in range(g_running_sum_size):
            for i in range(9):
                if ((g_current_sample - k) >= 0):
                    total_tested += g_results[k, stock, i]

        if total_tested > 0:
            if stock == 0:
                print("WIN: "),
            if stock == 1:
                print("IND: "),
            if stock == 2:
                print("WDO: "),
            if stock == 3:
                print("DOL: "),

            for i in range(9):
                ch1 = ' '
                ch2 = ' '

                if ((i == 0) or (i == 1) or (i == 2)): 
                    ch1 = 'i'
                if ((i == 3) or (i == 4) or (i == 5)):
                    ch1 = '!'
                if ((i == 6) or (i == 7) or (i == 8)):
                    ch1 = '-'

                if ((i == 0) or (i == 3) or (i == 6)): 
                    ch2 = 'i'
                if ((i == 1) or (i == 4) or (i == 7)):
                    ch2 = '!'
                if ((i == 2) or (i == 5) or (i == 8)):
                    ch2 = '-'

                print ("%c%c = %5.2lf, " % (ch1, ch2, 100.0 * r_sum(stock, i) / total_tested)),
            
            print ("== = %6.2lf:  " % (100.0 * (r_sum(stock, SS) + r_sum(stock, DD) + r_sum(stock, NN)) / total_tested)),

            sumv = r_sum(stock, SS) + r_sum(stock, SD) + r_sum(stock, SN)
            if (sumv != 0):
                print("gi %6.1lf  " % (100.0 * (3.0 * r_sum(stock, SS) - 3.0 * r_sum(stock, SD) - r_sum(stock, SN)) / (3.0 * sumv))),
            else:
                print("gi   ---   "),

            sumv = r_sum(stock, DD) + r_sum(stock, DS) + r_sum(stock, DN)
            if (sumv != 0):
                print ("g! %6.1lf  " % (100.0 * (3.0 * r_sum(stock, DD) - 3.0 * r_sum(stock, DS) - r_sum(stock, DN)) / (3.0 * sumv))),
            else:
                print ("g!   ---  "),

            if g_buy_sell_count[stock, 0]  > 0:
                print ("buy_sell_count = %2d, capital = %.2lf, return = %.4lf, p_return = %.4lf, invest = %d, hit_rate = %6.1lf" %
                        ( g_buy_sell_count[stock, 0], g_capital[stock, 0],
                        g_results[g_sample_statistics-1, stock, RETURN], g_results[g_sample_statistics-1, stock, P_RETURN],
                        g_results[g_sample_statistics-1, stock, INVEST],
                        100.0 * f_sum(stock, HITS) / (g_buy_sell_count[stock, 0])))
            else:
                print("buy_sell_count = %2d, capital = %.2lf, return = %.4lf, p_return = %.4lf, invest = %d, hit_rate = --- " %
                        (g_buy_sell_count[stock, 0], g_capital[stock, 0],
                        g_results[g_sample_statistics-1, stock, RETURN], g_results[g_sample_statistics-1, stock, P_RETURN],
                        g_results[g_sample_statistics-1, stock, INVEST]))

    total_capital = 0.0
    total_buy_sell = 0
    for stock in range(4):
        total_capital += g_capital[stock, 0]
        total_buy_sell += g_buy_sell_count[stock, 0]

    print ("num_periods_with_operations = %d, total_buy_sell = %d, average_final_capital = %.2lf\n" %
            (total_tested, total_buy_sell, total_capital / 4))

def show_statistics_exp(day_i):

    global g_stat_day
    
    total_hits = 0

    for stock in range(4):
        total_tested = 0
        for i in range(9):
            total_tested += f_sum(stock, i)

        if total_tested > 0:
            for i in range(9):
                
                g_stat_day[day_i, stock, i] =  100.0 * f_sum(stock, i) / total_tested

            g_stat_day[day_i, stock, ACC] = 100.0 * (f_sum(stock, SS) + f_sum(stock, DD) + f_sum(stock, NN)) / total_tested

            sumv = f_sum(stock, SS) + f_sum(stock, SD) + f_sum(stock, SN)
            if sumv != 0:
                g_stat_day[day_i, stock, GI] = 100.0 * (3.0 * f_sum(stock, SS) - 3.0 * f_sum(stock, SD) - f_sum(stock, SN)) / (3.0 * sumv)
            else:
                g_stat_day[day_i, stock, GI] = 0.0

            sumv = f_sum(stock, DD) + f_sum(stock, DS) + f_sum(stock, DN)
            if sum != 0:
                g_stat_day[day_i, stock, Gi] = 100.0 * (3.0 * f_sum(stock, DD) - 3.0 * f_sum(stock, DS) - f_sum(stock, DN)) / (3.0 * sumv)
            else:
                g_stat_day[day_i, stock, Gi] = 0.0

            if g_buy_sell_count[stock, 0] > 0:
                g_stat_day[day_i, stock, HITS] = f_sum(stock, HITS)
                total_hits += g_stat_day[day_i, stock, HITS]
            else:
                g_stat_day[day_i, stock, HITS] = 0.0

    #--------------- capital day

    total_capital = 0.0
    total_buy_sell = 0
    symbol = "" 
    for stock in range(4):
        total_capital += g_capital[stock, 0]
        total_buy_sell += g_buy_sell_count[stock, 0]

    stat_exp_day = statistics_exp()
    
    stat_exp_day.day = day_i
    stat_exp_day.avg_capital = total_capital / 4.0
    stat_exp_day.geral_capital = g_capital[4, 0]
    stat_exp_day.n_ops = total_buy_sell
    stat_exp_day.total_hits = total_hits

    print ("day_i=%d; avg_capital=%.2lf; geral_capital=%.2lf; n_ops=%d; hit_rate=%.1lf; " %
            (day_i, stat_exp_day.avg_capital, stat_exp_day.geral_capital, stat_exp_day.n_ops,
            100.0 * stat_exp_day.total_hits / stat_exp_day.n_ops)),

    for stock in range(4):

        if stock == 0:
            symbol = "WIN_"
        elif stock == 1: 
            symbol = "IND_"
        elif stock == 2:
            symbol = "WDO_"
        elif stock == 3:
            symbol = "DOL_"

        for i in range(9):
            ch1 = ' '
            ch2 = ' '

            if ((i == 0) or (i == 1) or (i == 2)):
                ch1 = 'i'
            if ((i == 3) or (i == 4) or (i == 5)):
                ch1 = '!'
            if ((i == 6) or (i == 7) or (i == 8)):
                ch1 = '-'

            if ((i == 0) or (i == 3) or (i == 6)):
                ch2 = 'i'
            if ((i == 1) or (i == 4) or (i == 7)):
                ch2 = '!'
            if ((i == 2) or (i == 5) or (i == 8)):
                ch2 = '-'

            print ("%s%c%c=%.2lf; " % (symbol, ch1, ch2, g_stat_day[day_i, stock, i])),

        print ("%s===%.2lf; " % (symbol, g_stat_day[day_i, stock, ACC])),
        print ("%sgi=%.1lf; " % (symbol, g_stat_day[day_i, stock, GI])),
        print ("%sg!=%.1lf; " % (symbol, g_stat_day[day_i, stock, Gi])),
               
        if g_buy_sell_count[stock, 0] > 0:
            print ("%shit_rate=%.1lf; " % (symbol,  100.0 * g_stat_day[day_i, stock, HITS] / g_buy_sell_count[stock, 0])),
        else:
            print ("%shit_rate=--; " % (symbol)),

        print ("%scapital=%.1lf; " % (symbol,  g_capital[stock, 0])),
        print ("%sn_ops=%d; " % (symbol,  g_buy_sell_count[stock, 0])),
    print("\n")

    stat_exp_day.capital_win = g_capital[0, 0]
    stat_exp_day.capital_ind = g_capital[1, 0]
    stat_exp_day.capital_wdo = g_capital[2, 0]
    stat_exp_day.capital_dol = g_capital[3, 0]

    stat_exp_day.n_ops_win = g_buy_sell_count[0, 0]
    stat_exp_day.n_ops_ind = g_buy_sell_count[1, 0]
    stat_exp_day.n_ops_wdo = g_buy_sell_count[2, 0]
    stat_exp_day.n_ops_dol = g_buy_sell_count[3, 0]
    
    return stat_exp_day

def mean_statistics_exp(day_i):

    n = 1.0 * day_i

    total_capital = 0.0
    total_geral_capital = 0.0
    total_capital_win = 0.0
    total_capital_ind = 0.0
    total_capital_wdo = 0.0
    total_capital_dol = 0.0

    total_hits = 0.0

    n_ops = 0
    n_ops_win = 0
    n_ops_ind = 0
    n_ops_wdo = 0
    n_ops_dol = 0

    mean_stat_day = numpy.zeros((4, 13))

    for i in range(day_i):
        total_capital    += g_stat_exp[i].avg_capital
        total_geral_capital    += g_stat_exp[i].geral_capital
        total_capital_win += g_stat_exp[i].capital_win
        total_capital_ind += g_stat_exp[i].capital_ind
        total_capital_wdo += g_stat_exp[i].capital_wdo
        total_capital_dol += g_stat_exp[i].capital_dol

        total_hits += g_stat_exp[i].total_hits

        n_ops    += g_stat_exp[i].n_ops
        n_ops_win    += g_stat_exp[i].n_ops_win
        n_ops_ind    += g_stat_exp[i].n_ops_ind
        n_ops_wdo    += g_stat_exp[i].n_ops_wdo
        n_ops_dol    += g_stat_exp[i].n_ops_dol

        for stock in range(4):
            for j in range(13):
                mean_stat_day[stock, j] += g_stat_day[i, stock, j]

    print ("day_i=Mean; avg_capital=%.2lf; avg_geral_capital=%.2lf; n_ops=%.2lf; hit_rate=%.1lf; " %
            (total_capital / n, total_geral_capital / n, (1.0 * n_ops) / n, 100.0 * total_hits / n_ops)),
            
    symbol = ""
    for stock in range(4):
        if stock == 0:
            symbol = "WIN_"
        elif stock == 1: 
            symbol = "IND_"
        elif stock == 2:
            symbol = "WDO_"
        elif stock == 3:
            symbol = "DOL_"

        for j in range(9):
            ch1 = ' '
            ch2 = ' '

            if ((j == 0) or (j == 1) or (j == 2)):
                ch1 = 'i'
            if ((j == 3) or (j == 4) or (j == 5)):
                ch1 = '!'
            if ((j == 6) or (j == 7) or (j == 8)):
                ch1 = '-'

            if ((j == 0) or (j == 3) or (j == 6)):
                ch2 = 'i'
            if ((j == 1) or (j == 4) or (j == 7)):
                ch2 = '!'
            if ((j == 2) or (j == 5) or (j == 8)):
                ch2 = '-'

            print ("%s%c%c=%.2lf; " % (symbol, ch1, ch2, mean_stat_day[stock, j] / n)),

        print ("%s===%.2lf; " % (symbol, mean_stat_day[stock, ACC] / n)),
        print ("%sgi=%.1lf; " % (symbol, mean_stat_day[stock, GI] / n)),
        print ("%sg!=%.1lf; " % (symbol, mean_stat_day[stock, Gi] / n)),

        if stock == 0:
            if n_ops_win > 0:
                print ("%shit_rate=%.1lf; " % (symbol,  100.0 * mean_stat_day[stock, HITS] / n_ops_win)),
            else:
                print ("%shit_rate=--; " % (symbol)),
            print ("%scapital=%.2lf; %sn_ops=%.2lf; " % (symbol, total_capital_win / n, symbol, (1.0 * n_ops_win) / n)),

        if stock == 1:
            if n_ops_ind > 0: 
                print ("%shit_rate=%.1lf; " % (symbol,  100.0 * mean_stat_day[stock, HITS] / n_ops_ind)),
            else:
                print ("%shit_rate=--; " % (symbol)), 
            print ("%scapital=%.2lf; %sn_ops=%.2lf; " % (symbol, total_capital_ind / n, symbol, (1.0 * n_ops_ind) / n)),
            
        if stock == 2:
            if n_ops_wdo > 0: 
                print ("%shit_rate=%.1lf; " % (symbol,  100.0 * mean_stat_day[stock, HITS] / n_ops_wdo)),
            else:
                print ("%shit_rate=--; " % (symbol)),
            print ("%scapital=%.2lf; %sn_ops=%.2lf; " % (symbol, total_capital_wdo / n, symbol, (1.0 * n_ops_wdo) / n)),

        if stock == 3:
            if n_ops_dol > 0:
                print ("%shit_rate=%.1lf; " % (symbol,  100.0 * mean_stat_day[stock, HITS] / n_ops_dol)),
            else:
                print("%shit_rate=--; " % (symbol)),
            print ("%scapital=%.2lf; %sn_ops=%.2lf; " % (symbol, total_capital_dol / n, symbol, (1.0 * n_ops_dol) / n)),      
    print("\n")

def print_capital():

    acc = 0.0
    total_hits = 0
    total_miss = 0
    total_ops = 0;
    total_longs = 0
    predc = 0.0
    recall = 0.0

    for i in range(4):
        total_hits += g_n_hits[i, 0]
        total_miss += g_n_miss[i, 0]
        total_ops  += g_n_ops[i, 0]
        total_longs += g_buy_sell_count[i, 0]

        if g_n_ops[i, 0] > 0:
            acc = (100.0 * g_n_hits[i, 0]) / g_n_ops[i, 0]
            print ("capital[%d]=%.2lf longs=%d ops=%d hits=%d miss=%d acc=%.1lf" %
                   (i, g_capital[i, 0], g_buy_sell_count[i, 0], 
                    g_n_ops[i, 0], g_n_hits[i, 0], g_n_miss[i, 0], acc))
        else:
            print ("capital[%d]=%.2lf longs=%d ops=%d hits=%d miss=%d acc=--" %
                   (i, g_capital[i, 0], g_buy_sell_count[i, 0], 
                    g_n_ops[i, 0], g_n_hits[i, 0], g_n_miss[i, 0]))
            

        if (g_tp[i, 0] + g_fp[i, 0]) > 0:
            predc = 100.0 * g_tp[i, 0] / (g_tp[i, 0] + g_fp[i, 0])
            recall = 100.0 * g_tp[i, 0] / (g_tp[i, 0] + g_fn[i, 0])

            print ("tp=%1.1lf fp=%1.1lf tn=%1.1lf fn=%1.1lf predc=%.2lf rec=%.2lf" % 
                   (g_tp[i, 0], g_fp[i, 0], g_tn[i, 0], g_fn[i, 0], predc, recall))
        else:
            print ("tp=%1.1lf fp=%1.1lf tn=%1.1lf fn=%1.1lf predc=-- rec=--" % 
                   (g_tp[i, 0], g_fp[i, 0], g_tn[i, 0], g_fn[i, 0]))

    if total_ops > 0:
        acc = (100.0 * total_hits) / total_ops
        print ("capital[%d]=%.2lf longs=%d ops=%d hits=%d miss=%d acc=%.1lf" %
               (4, g_capital[4, 0], total_longs, 
                total_ops, total_hits, total_miss, acc))
    else:
        print ("capital[%d]=%.2lf longs=%d ops=%d hits=%d miss=%d acc=--" %
               (4, g_capital[4, 0], total_longs, 
                total_ops, total_hits, total_miss))

def calculate_u_theil(t, y):
    
    num = 0
    den = 0
        
    for i in range(0, len(t)):
        num += (t[i] - y[i]) * (t[i] - y[i])
        
    for i in range(len(t) - 1):
        den += (t[i] - t[i+1]) * (t[i] - t[i+1])
    
    if den > 0:
        return num / den
    else:
        return -1

def calculate_pocid(t, y):
    
    d = 0

    for i in range(1, len(t)):
        if (t[i] - t[i-1])*(y[i] - y[i-1]) > 0:
            d += 1
      
    return 100.0 * d / len(t)

def calculate_arv(t, y):
    
    mean_t = numpy.mean(t)
    num = 0
    den = 0

    for i in range(0, len(t)):
        num += (y[i] - t[i]) * (y[i] - t[i])
        den += (y[i] - mean_t) * (y[i] - mean_t)
        
    if den > 0:
        return (1.0 / len(t)) * (num / den)
    else:
        return -1
 
def calculate_metrics(t, y):

    for i in range(4):
        if i == 0:
            print "WIN ",
        elif i == 1:
            print "IND ",
        elif i == 2:
            print "WDO ",
        else:
            print "DOL ",
        testTheil = calculate_u_theil(t[i, :], y[i, :])
        print ('Test U Theil= %.6lf ' % (testTheil)),
        testPocid = calculate_pocid(t[i, :], y[i, :])
        print ('Test POCID= %.6lf ' % (testPocid)),
        testArv = calculate_arv(t[i, :], y[i, :])
        print ('Test ARV= %.6lf' % (testArv))

def increment(day_data, options, param):
    
    global g_current_sample
    
    if param <= 0:
        g_current_sample = 0
    else:
        for i in range(param):
            g_current_sample = sample_next_period(day_data, options, g_current_sample)
   
def save_predicted_values(t, y):
    f = open("nn_4_4_1_n_256s_10dias_shuffle_CACO.csv", "w+")
    f.write("WIN_T; WIN_Y; IND_T; IND_Y; WDO_T; WDO_Y; DOL_T; DOL_Y\n")
 
    for i in range(len(t[0, :])):
        line = "%lf; %lf; %lf; %lf; %lf; %lf; %lf; %lf\n" % (t[0, i], 
            y[0, i], t[1, i], y[1, i], t[2, i], y[2, i], t[3, i], y[3, i])
        f.write(line)
         
    f.close()
    return 0
    
def main():
    
    global g_prediction, g_net_phase, g_stat_exp
    global g_n_samples_train
    
    # parse command-line
    parser = OptionParser()
    (options, args) = parse_cmdline(parser)
    
    day_i = 0
    n_days = 10#len(day_data_names)
    loaded = 0
    
    first_time = 1
    n_neurons = 4
    while day_i < n_days:
        
        #time_steps = options.n_in
        batch_size = 1
        #features = 1

        sgd = keras.optimizers.SGD(lr = 0.07, decay = 0.0, momentum = 0.0, nesterov = False)
        
        # create model
        model_win = Sequential()
        #model.add(LSTM(4, batch_input_shape=(batch_size, time_steps, features), stateful=True))
        model_win.add(Dense(n_neurons, input_dim=options.n_in, activation='tanh'))
        model_win.add(Dense(1))
        model_win.compile(loss='mse', optimizer=sgd)
        
        model_ind = Sequential()
        #model.add(LSTM(4, batch_input_shape=(batch_size, time_steps, features), stateful=True))
        model_ind.add(Dense(n_neurons, input_dim=options.n_in, activation='tanh'))
        model_ind.add(Dense(1))
        model_ind.compile(loss='mse', optimizer=sgd)
        
        model_wdo = Sequential()
        #model.add(LSTM(4, batch_input_shape=(batch_size, time_steps, features), stateful=True))
        model_wdo.add(Dense(n_neurons, input_dim=options.n_in, activation='tanh'))
        model_wdo.add(Dense(1))
        model_wdo.compile(loss='mse', optimizer=sgd)
        
        model_dol = Sequential()
        #model.add(LSTM(4, batch_input_shape=(batch_size, time_steps, features), stateful=True))
        model_dol.add(Dense(n_neurons, input_dim=options.n_in, activation='tanh'))
        model_dol.add(Dense(1))
        model_dol.compile(loss='mse', optimizer=sgd)
    
        if first_time == 1:
            model_win.summary()
            first_time = 0
            #exit()
            
        reset_statistics()
        
        day_data = load_day(day_i, options)
        
        g_net_phase = TRAIN_PHASE
        
        #increment(day_data, options, options.n_in+1)
        
        print g_current_sample

        tick = time_to_start(day_data)
        
        while tick == 0:
            #move_1_tick(day_data, options, loaded)
            increment(day_data, options, 1)
            tick = time_to_start(day_data)
        
        #print g_current_sample
        print day_data.dataset[g_current_sample, :]
        
        input_all_data_win = None
        input_all_data_ind = None
        input_all_data_wdo = None
        input_all_data_dol = None
        
        output_all_data = None
        
        while tick != 0:
            loaded, input_data = load_input(day_data, options)
            if loaded == 1:
                #print g_current_sample
                #print input_data
                output_data = load_output(day_data, options)
                #print output_data

#                 # LSTM reshape input to be [samples, time steps, features]
#                 #input_data = numpy.reshape(input_data, (input_data.shape[0], input_data.shape[1], features))
                  
                if input_all_data_win is None:
                    input_all_data_win = numpy.copy(input_data[0, :])
                else:
                    input_all_data_win = numpy.row_stack((input_all_data_win, input_data[0, :]))
                    
                if input_all_data_ind is None:
                    input_all_data_ind = numpy.copy(input_data[1, :])
                else:
                    input_all_data_ind = numpy.row_stack((input_all_data_ind, input_data[1, :]))
     
                if input_all_data_wdo is None:
                    input_all_data_wdo = numpy.copy(input_data[2, :])
                else:
                    input_all_data_wdo = numpy.row_stack((input_all_data_wdo, input_data[2, :]))
                     
                if input_all_data_dol is None:
                    input_all_data_dol = numpy.copy(input_data[3, :])
                else:
                    input_all_data_dol = numpy.row_stack((input_all_data_dol, input_data[3, :]))
                    
                if output_all_data is None:
                    output_all_data = numpy.copy(output_data)
                else:
                    output_all_data = numpy.column_stack((output_all_data, output_data))
                
            move_1_tick(day_data, options, loaded)
            
            tick = time_to_train(day_data)
        
#         print input_all_data.shape
        print output_all_data.shape   
        print "BEGIN TRAIN "
        model_win = train_model(model_win, input_all_data_win, output_all_data[0, :])
        model_ind = train_model(model_ind, input_all_data_ind, output_all_data[1, :])
        model_wdo = train_model(model_wdo, input_all_data_wdo, output_all_data[2, :])
        model_dol = train_model(model_dol, input_all_data_dol, output_all_data[3, :])
        g_n_samples_train = len(output_all_data[0,:])
        print g_n_samples_train
        print "END TRAIN "
        #exit()
         
#         trainPredict = model.predict(input_all_data, batch_size=batch_size)
#             
#         hits_train, miss_train = calculate_hit_rate(output_all_data, trainPredict)
#         print ('Train hits= %d miss= %d acc= %.2lf' % (hits_train, miss_train, 100.0 * (float(hits_train) / float(hits_train + miss_train)) ))
# 
#         plt.plot(output_all_data)
#         plt.plot(trainPredict)
#         plt.show()
#         #exit(0)
        #print g_current_sample
        print day_data.dataset[g_current_sample, :]
        
        g_net_phase = TEST_PHASE
        
        tick = time_to_test(day_data);
        
        first_test_id = output_all_data.shape[1]
        print first_test_id
        predicted_all_data = None
        
        n = 0
        elapsed_time = 0
        elapsed_time_aux = numpy.zeros((4, 1))
        while tick != 0:
            loaded, input_data = load_input(day_data, options)
         
            if loaded == 1:
                #print g_current_sample
                # preditc and copy prediction to global variable
                g_prediction[0, 0] = model_win.predict(numpy.reshape(input_data[0, :], (1, input_data[0, :].shape[0])), batch_size=batch_size)
                g_prediction[1, 0] = model_ind.predict(numpy.reshape(input_data[1, :], (1, input_data[1, :].shape[0])), batch_size=batch_size)
                g_prediction[2, 0] = model_wdo.predict(numpy.reshape(input_data[2, :], (1, input_data[2, :].shape[0])), batch_size=batch_size)
                g_prediction[3, 0] = model_dol.predict(numpy.reshape(input_data[3, :], (1, input_data[3, :].shape[0])), batch_size=batch_size)
#                 g_prediction[0, 0] = numpy.random.uniform(-50, 50)
#                 g_prediction[1, 0] = numpy.random.uniform(-50, 50)
#                 g_prediction[2, 0] = numpy.random.uniform(-5, 5)
#                 g_prediction[3, 0] = numpy.random.uniform(-5, 5)
                
                if predicted_all_data is None:
                    predicted_all_data = numpy.copy(g_prediction)
                else:
                    predicted_all_data = numpy.column_stack((predicted_all_data, g_prediction))
                 
                output_data = load_output(day_data, options)
                 
                compute_prediction_statistics(output_data) 
                compute_capital_evolution(output_data)
                 
                # insert data to train
                if input_all_data_win is None:
                    input_all_data_win = numpy.copy(input_data[0, :])
                else:
                    input_all_data_win = numpy.row_stack((input_all_data_win, input_data[0, :]))
                    
                if input_all_data_ind is None:
                    input_all_data_ind = numpy.copy(input_data[1, :])
                else:
                    input_all_data_ind = numpy.row_stack((input_all_data_ind, input_data[1, :]))
     
                if input_all_data_wdo is None:
                    input_all_data_wdo = numpy.copy(input_data[2, :])
                else:
                    input_all_data_wdo = numpy.row_stack((input_all_data_wdo, input_data[2, :]))
                     
                if input_all_data_dol is None:
                    input_all_data_dol = numpy.copy(input_data[3, :])
                else:
                    input_all_data_dol = numpy.row_stack((input_all_data_dol, input_data[3, :]))
                
                output_all_data = numpy.column_stack((output_all_data, output_data))
                 
                #show_statistics(day_data, options)
                 
                # train network
#                 model_win, elapsed_time_aux[0] = train_model_batch(model_win, numpy.reshape(input_data[0, :], (1, input_data[0, :].shape[0])), output_data[0, :])
#                 model_ind, elapsed_time_aux[1] = train_model_batch(model_ind, numpy.reshape(input_data[1, :], (1, input_data[1, :].shape[0])), output_data[1, :])
#                 model_wdo, elapsed_time_aux[2] = train_model_batch(model_wdo, numpy.reshape(input_data[2, :], (1, input_data[2, :].shape[0])), output_data[2, :])
#                 model_dol, elapsed_time_aux[3] = train_model_batch(model_dol, numpy.reshape(input_data[3, :], (1, input_data[3, :].shape[0])), output_data[3, :])

                # train network with n last values
                model_win, elapsed_time_aux[0] = train_model_batch(model_win, input_all_data_win, output_all_data[0, :])
                model_ind, elapsed_time_aux[1] = train_model_batch(model_ind, input_all_data_ind, output_all_data[1, :])
                model_wdo, elapsed_time_aux[2] = train_model_batch(model_wdo, input_all_data_wdo, output_all_data[2, :])
                model_dol, elapsed_time_aux[3] = train_model_batch(model_dol, input_all_data_dol, output_all_data[3, :])

#                 model_win, elapsed_time_aux[0] = train_model_batch(model_win, numpy.reshape(input_data[0, :], (1, input_data[0, :].shape[0])), output_data[0, :])
#                 model_ind, elapsed_time_aux[1] = train_model_batch(model_ind, numpy.reshape(input_data[1, :], (1, input_data[1, :].shape[0])), output_data[1, :])
#                 model_wdo, elapsed_time_aux[2] = train_model_batch(model_wdo, numpy.reshape(input_data[2, :], (1, input_data[2, :].shape[0])), output_data[2, :])
#                 model_dol, elapsed_time_aux[3] = train_model_batch(model_dol, numpy.reshape(input_data[3, :], (1, input_data[3, :].shape[0])), output_data[3, :])
        
                
                elapsed_time += numpy.sum(elapsed_time_aux) / 4.0
                n += 1
#                 model_win = train_model(model_win, input_all_data_win, output_all_data[0, :])
#                 model_ind = train_model(model_ind, input_all_data_ind, output_all_data[1, :])
#                 model_wdo = train_model(model_wdo, input_all_data_wdo, output_all_data[2, :])
#                 model_dol = train_model(model_dol, input_all_data_dol, output_all_data[3, :])
                
            move_1_tick(day_data, options, loaded)
                    
            tick = time_to_test(day_data)
        
        print "Elapsed time= ", elapsed_time / n
        print n
    
        test_all_data = output_all_data[:, first_test_id:output_all_data.shape[1]]
        print test_all_data.shape, predicted_all_data.shape
        hits_test0, miss_test0 = calculate_hit_rate(test_all_data[0, :], predicted_all_data[0, :])
        hits_test1, miss_test1 = calculate_hit_rate(test_all_data[1, :], predicted_all_data[1, :])
        hits_test2, miss_test2 = calculate_hit_rate(test_all_data[2, :], predicted_all_data[2, :])
        hits_test3, miss_test3 = calculate_hit_rate(test_all_data[3, :], predicted_all_data[3, :])
        print hits_test0, miss_test0
        print hits_test1, miss_test1
        print hits_test2, miss_test2
        print hits_test3, miss_test3 
        print ('Test hits= %d miss= %d acc= %.2lf' % (hits_test0, miss_test0, 100.0 * (float(hits_test0) / float(hits_test0 + miss_test0)) ))
        print ('Test hits= %d miss= %d acc= %.2lf' % (hits_test1, miss_test1, 100.0 * (float(hits_test1) / float(hits_test1 + miss_test1)) ))
        print ('Test hits= %d miss= %d acc= %.2lf' % (hits_test2, miss_test2, 100.0 * (float(hits_test2) / float(hits_test2 + miss_test2)) ))
        print ('Test hits= %d miss= %d acc= %.2lf' % (hits_test3, miss_test3, 100.0 * (float(hits_test3) / float(hits_test3 + miss_test3)) ))
         
        calculate_metrics(test_all_data, predicted_all_data)

#         plt.plot(test_all_data[0, :])
#         plt.plot(predicted_all_data[0, :])
#         plt.show()
        
        if day_i == 0:
            test_days_data = numpy.copy(test_all_data)
            pred_days_data = numpy.copy(predicted_all_data)
        else:
            test_days_data = numpy.column_stack((test_days_data, test_all_data))
            pred_days_data = numpy.column_stack((pred_days_data, predicted_all_data))
            
        print test_days_data.shape, test_all_data.shape
        #save_predicted_values(test_all_data, predicted_all_data)
        
        print g_current_sample
        print day_data.dataset[g_current_sample, :]
        
        stat_exp = show_statistics_exp(day_i)
        g_stat_exp.append(stat_exp)
        
        day_i += 1
    
        model_win = None
        model_ind = None
        model_wdo = None
        model_dol = None
        
    mean_statistics_exp(day_i)
    print_capital()
    save_predicted_values(test_days_data, pred_days_data)
    
if __name__ == "__main__":
    main()