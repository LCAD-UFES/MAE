diary 'out_teste_rw_data.txt'
fnames = dir('DATA');

for i=1:1:length(fnames)
    if i >= 3
        fnames(i).name
        name = strcat('DATA/', fnames(i).name);
        [WIN_MID, IND_MID, WDO_MID, DOL_MID] = importfile(name, 2, inf);
        q = [32 64 128 256 32 64 128 256];
        flag = logical([1 1 1 1 0 0 0 0]);
        'WIN'
        [h,pValue,stat,cValue,ratio] = vratiotest(WIN_MID,'period',q,'IID',flag)
        'IND'
        [h,pValue,stat,cValue,ratio] = vratiotest(IND_MID,'period',q,'IID',flag)
        'WDO'
        [h,pValue,stat,cValue,ratio] = vratiotest(WDO_MID,'period',q,'IID',flag)
        'DOL'
        [h,pValue,stat,cValue,ratio] = vratiotest(DOL_MID,'period',q,'IID',flag)
    end
end
    
diary off
% [WIN_MID, IND_MID, WDO_MID, DOL_MID] = importfile('DATA/20160301_01_BOOK_TOP_PRC.csv', 2, inf);
% 
% q = [32 64 128 256 32 64 128 256];
% flag = logical([1 1 1 1 0 0 0 0]);
% [h,pValue,stat,cValue,ratio] = vratiotest(WIN_MID,'period',q,'IID',flag)
% [h,pValue,stat,cValue,ratio] = vratiotest(IND_MID,'period',q,'IID',flag)
% [h,pValue,stat,cValue,ratio] = vratiotest(WDO_MID,'period',q,'IID',flag)
% [h,pValue,stat,cValue,ratio] = vratiotest(DOL_MID,'period',q,'IID',flag)