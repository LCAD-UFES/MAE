diary 'out_teste_rw_data_all.txt'
fnames = dir('DATA');

for i=1:1:length(fnames)
    if i >= 3
        fnames(i).name
        name = strcat('DATA/', fnames(i).name);
        [WIN_MID, IND_MID, WDO_MID, DOL_MID] = importfile(name, 2, inf);
        if i == 3
            WIN = WIN_MID;
            IND = IND_MID;
            WDO = WDO_MID;
            DOL = DOL_MID;
        else
            WIN = vertcat(WIN, WIN_MID);
            IND = vertcat(IND, IND_MID);
            WDO = vertcat(WDO, WDO_MID);
            DOL = vertcat(DOL, DOL_MID);
        end
    end
end

length(WIN)

q = [32 64 128 256 32 64 128 256];
flag = logical([1 1 1 1 0 0 0 0]);
'WIN'
[h,pValue,stat,cValue,ratio] = vratiotest(WIN,'period',q,'IID',flag)
'IND'
[h,pValue,stat,cValue,ratio] = vratiotest(IND,'period',q,'IID',flag)
'WDO'
[h,pValue,stat,cValue,ratio] = vratiotest(WDO,'period',q,'IID',flag)
'DOL'
[h,pValue,stat,cValue,ratio] = vratiotest(DOL,'period',q,'IID',flag)
    
diary off
% [WIN_MID, IND_MID, WDO_MID, DOL_MID] = importfile('DATA/20160301_01_BOOK_TOP_PRC.csv', 2, inf);
% 
% q = [32 64 128 256 32 64 128 256];
% flag = logical([1 1 1 1 0 0 0 0]);
% [h,pValue,stat,cValue,ratio] = vratiotest(WIN_MID,'period',q,'IID',flag)
% [h,pValue,stat,cValue,ratio] = vratiotest(IND_MID,'period',q,'IID',flag)
% [h,pValue,stat,cValue,ratio] = vratiotest(WDO_MID,'period',q,'IID',flag)
% [h,pValue,stat,cValue,ratio] = vratiotest(DOL_MID,'period',q,'IID',flag)